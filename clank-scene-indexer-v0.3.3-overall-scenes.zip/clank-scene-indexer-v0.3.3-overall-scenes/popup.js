const tabStatus = document.getElementById("tabStatus");
const launchButton = document.getElementById("launch");
const message = document.getElementById("message");

function isCreatorProfile(urlString) {
  try {
    const url = new URL(urlString);
    if (url.hostname !== "www.clank.world" && url.hostname !== "clank.world") return false;
    return /^\/@(?!c\/)[^/?#]+\/?$/i.test(url.pathname);
  } catch {
    return false;
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function refreshState() {
  message.textContent = "";
  message.classList.remove("error");
  const tab = await getActiveTab();
  if (!tab?.id) {
    tabStatus.textContent = "No active tab found.";
    launchButton.disabled = true;
    return;
  }
  const url = tab.url || "";
  tabStatus.textContent = url || "Unknown URL";
  if (!isCreatorProfile(url)) {
    launchButton.disabled = true;
    message.textContent = "Open your Clank creator profile first.";
    message.classList.add("error");
    return;
  }
  launchButton.disabled = false;
}

launchButton.addEventListener("click", async () => {
  launchButton.disabled = true;
  message.textContent = "Launching collector…";
  message.classList.remove("error");
  try {
    const tab = await getActiveTab();
    if (!tab?.id || !isCreatorProfile(tab.url || "")) {
      throw new Error("The active tab is not a Clank creator profile.");
    }
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["collector-main.js"],
      world: "MAIN",
      injectImmediately: true
    });
    message.textContent = "Collector launched. Use the floating panel on Clank.";
  } catch (error) {
    console.error(error);
    message.textContent = `Launch failed: ${error?.message || error}`;
    message.classList.add("error");
    launchButton.disabled = false;
  }
});

refreshState().catch(error => {
  console.error(error);
  tabStatus.textContent = "Could not inspect the current tab.";
  message.textContent = String(error?.message || error);
  message.classList.add("error");
});
