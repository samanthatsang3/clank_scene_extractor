/*
======================================================================
CLANK SCENE COLLECTOR
======================================================================

FEATURES
----------------------------------------------------------------------

1. Run from YOUR Clank user profile.

   Example:
   https://www.clank.world/@Samantha_

2. Detects:

   User profile:
   https://www.clank.world/@Samantha_

   Screen name:
   Sam

3. Opens:

   https://www.clank.world/your-characters

   Creator verification is intentionally skipped ONLY during this
   initial character-discovery step.

4. Dynamically discovers your @c/... characters.

5. PAUSES and gives you a character-selection screen.

   For every character:

      ☑ Scan character
      ☐ Allow hidden/private scenes

   Default:
      Scan character              = ON
      Allow hidden/private scenes = OFF

6. Search-card creator verification:

      by Sam       ✓
      by someone else   ✗

7. Scene visibility:

   Character option OFF:
      Public Scene   ✓
      Private Scene  ✗
      Unknown        ✗

   Character option ON:
      Public Scene   ✓
      Private Scene  ✓
      Unknown        ✗

8. Scene Details creator verification:

      Created by Sam   ✓

   If Clank exposes the creator profile URL, it must also match
   the user profile the script was launched from.

9. Exact @c/... character check is also performed when Clank exposes
   a machine-readable character URL.

10. Collects:

      Character

      - Scene title
      - Scene visibility
      - Scene URL
      - Scene title image URL

11. Uses img.currentSrc FIRST for image extraction.

   IMPORTANT:
   Clank image URLs contain commas:

      w=640,fit=scale-down,q=100,f=webp

   This script does NOT split srcset by commas.

======================================================================
*/


(() => {

  "use strict";


  /* ============================================================
     SETTINGS
     ============================================================ */

  const YOUR_CHARACTERS_URL =
    "https://www.clank.world/your-characters";


  const PAGE_LOAD_DELAY =
    1400;


  const SCROLL_DELAY =
    450;


  const AFTER_CLICK_DELAY =
    650;


  const SCENE_TIMEOUT =
    7000;


  const MODAL_TIMEOUT =
    5500;


  const MAX_CHARACTER_SCROLL_PASSES =
    30;


  const MAX_SEARCH_SCROLL_PASSES =
    14;


  /*
  Optional debugging.

  null = normal behavior.

  Example:

      const TEST_ONLY = "Rinak";
      const TEST_ONLY = "Yuna Park";

  This filters AFTER /your-characters discovery.
  */

  const TEST_ONLY =
    null;


  /* ============================================================
     CLANK CHECK
     ============================================================ */

  if (
    !location.hostname.endsWith(
      "clank.world"
    )
  ) {

    alert(
      "Open your Clank user profile while signed in, then run this script."
    );

    return;

  }


  /* ============================================================
     GENERAL HELPERS
     ============================================================ */

  const sleep =
    milliseconds =>
      new Promise(
        resolve =>
          setTimeout(
            resolve,
            milliseconds
          )
      );


  function cleanText(
    value
  ) {

    return String(
      value || ""
    )
      .replace(
        /\u00a0/g,
        " "
      )
      .replace(
        /[ \t]+/g,
        " "
      )
      .replace(
        /\n\s*\n+/g,
        "\n"
      )
      .trim();

  }


  function normalizedName(
    value
  ) {

    return cleanText(
      value
    )
      .toLocaleLowerCase();

  }


  function escapeHtml(
    value
  ) {

    return String(
      value ?? ""
    )
      .replaceAll(
        "&",
        "&amp;"
      )
      .replaceAll(
        "<",
        "&lt;"
      )
      .replaceAll(
        ">",
        "&gt;"
      )
      .replaceAll(
        '"',
        "&quot;"
      )
      .replaceAll(
        "'",
        "&#039;"
      );

  }


  function escapeRegExp(
    value
  ) {

    return String(
      value
    ).replace(
      /[.*+?^${}()|[\]\\]/g,
      "\\$&"
    );

  }


  function absoluteUrl(
    value,
    base =
      "https://www.clank.world/"
  ) {

    try {

      return new URL(
        value,
        base
      ).href;

    } catch {

      return "";

    }

  }


  function normalizeUrl(
    value
  ) {

    try {

      const url =
        new URL(
          value,
          "https://www.clank.world/"
        );


      url.hash =
        "";


      return url.href;

    } catch {

      return "";

    }

  }


  function normalizePathUrl(
    value
  ) {

    try {

      const url =
        new URL(
          value,
          "https://www.clank.world/"
        );


      url.search =
        "";


      url.hash =
        "";


      url.pathname =
        url.pathname.replace(
          /\/+$/,
          ""
        );


      return (
        url.origin +
        url.pathname
      ).toLocaleLowerCase();

    } catch {

      return "";

    }

  }


  /* ============================================================
     USER PROFILE
     ============================================================ */

  function normalizeUserProfileUrl(
    value
  ) {

    try {

      const url =
        new URL(
          value,
          location.origin
        );


      if (
        !url.hostname.endsWith(
          "clank.world"
        )
      ) {

        return "";

      }


      /*
      Valid:
          /@Samantha_

      Invalid:
          /@c/yunapark
      */

      if (
        !/^\/@(?!c\/)[^/?#]+\/?$/i.test(
          url.pathname
        )
      ) {

        return "";

      }


      url.search =
        "";


      url.hash =
        "";


      url.pathname =
        url.pathname.replace(
          /\/+$/,
          ""
        );


      return (
        url.origin +
        url.pathname
      ).toLocaleLowerCase();

    } catch {

      return "";

    }

  }


  const USER_PROFILE_URL_NORMALIZED =
    normalizeUserProfileUrl(
      location.href
    );


  if (
    !USER_PROFILE_URL_NORMALIZED
  ) {

    alert(
      "Run this script from your Clank USER profile.\n\nExample:\nhttps://www.clank.world/@Samantha_"
    );

    return;

  }


  const profileUrl =
    new URL(
      location.href
    );


  const USER_PROFILE_URL =
    profileUrl.origin +
    profileUrl.pathname.replace(
      /\/+$/,
      ""
    );


  const USER_HANDLE =
    decodeURIComponent(
      profileUrl.pathname
        .replace(
          /^\/@/,
          ""
        )
        .replace(
          /\/+$/,
          ""
        )
    );


  /* ============================================================
     SCREEN NAME DETECTION
     ============================================================ */

  function cleanProfileNameCandidate(
    value
  ) {

    let text =
      cleanText(
        value
      );


    if (!text) {

      return "";

    }


    /*
    Example:

        Sam | Clank.world

    ->

        Sam
    */

    text =
      text.replace(
        /\s*(?:\||[-–—])\s*Clank(?:\.world)?\s*$/i,
        ""
      );


    /*
    Example:

        Sam @Samantha_

    ->

        Sam
    */

    const handleSuffix =
      new RegExp(
        "\\s*@?" +
        escapeRegExp(
          USER_HANDLE
        ) +
        "\\s*$",
        "i"
      );


    return text
      .replace(
        handleSuffix,
        ""
      )
      .trim();

  }


  function looksLikeUsableScreenName(
    value
  ) {

    const text =
      cleanText(
        value
      );


    if (
      !text ||
      text.length >
        80
    ) {

      return false;

    }


    const lower =
      normalizedName(
        text
      );


    if (
      lower ===
        normalizedName(
          USER_HANDLE
        ) ||
      lower ===
        normalizedName(
          "@" +
          USER_HANDLE
        )
    ) {

      return false;

    }


    const junk =
      new Set([
        "notifications",
        "home",
        "your characters",
        "studio",
        "scenes",
        "characters",
        "users",
        "tags",
        "shop",
        "community",
        "edit",
        "edit profile",
        "settings",
        "followers",
        "following",
        "messages",
        "start chat",
        "continue chat",
        "wishes"
      ]);


    if (
      junk.has(
        lower
      )
    ) {

      return false;

    }


    if (
      /^@c\//i.test(
        text
      )
    ) {

      return false;

    }


    return true;

  }


  function detectScreenNameFromProfile(
    doc
  ) {

    /*
    ------------------------------------------------------------
    1. Browser tab title.

       Sam | Clank.world
    ------------------------------------------------------------
    */

    const fromTitle =
      cleanProfileNameCandidate(
        doc.title
      );


    if (
      looksLikeUsableScreenName(
        fromTitle
      )
    ) {

      return fromTitle;

    }


    /*
    ------------------------------------------------------------
    2. Metadata.
    ------------------------------------------------------------
    */

    const metadata =
      [
        doc.querySelector(
          'meta[property="og:title"]'
        )
          ?.getAttribute(
            "content"
          ),

        doc.querySelector(
          'meta[name="twitter:title"]'
        )
          ?.getAttribute(
            "content"
          )
      ];


    for (
      const raw of metadata
    ) {

      const value =
        cleanProfileNameCandidate(
          raw
        );


      if (
        looksLikeUsableScreenName(
          value
        )
      ) {

        return value;

      }

    }


    /*
    ------------------------------------------------------------
    3. Find exact @handle and inspect only nearby profile text.
    ------------------------------------------------------------
    */

    const exactHandle =
      "@" +
      USER_HANDLE;


    const handles =
      [
        ...doc.querySelectorAll(
          "span,a,div,p,strong,b,h1,h2,h3,h4"
        )
      ]
        .filter(
          element => {

            if (
              element.children.length >
              2
            ) {

              return false;

            }


            const text =
              cleanText(
                element.innerText ||
                element.textContent
              );


            if (
              normalizedName(
                text
              ) !==
              normalizedName(
                exactHandle
              )
            ) {

              return false;

            }


            try {

              const rect =
                element.getBoundingClientRect();


              return (
                rect.width >
                  0 &&
                rect.height >
                  0
              );

            } catch {

              return false;

            }

          }
        );


    handles.sort(
      (a, b) =>
        b.getBoundingClientRect()
          .left -
        a.getBoundingClientRect()
          .left
    );


    for (
      const handleElement of handles
    ) {

      const handleRect =
        handleElement
          .getBoundingClientRect();


      let scope =
        handleElement.parentElement;


      const candidates =
        [];


      for (
        let depth = 0;
        depth <
          7 &&
        scope;
        depth++,
        scope =
          scope.parentElement
      ) {

        const elements =
          [
            ...scope.querySelectorAll(
              "h1,h2,h3,h4,strong,b,span,p,a"
            )
          ];


        for (
          const element of elements
        ) {

          if (
            element ===
            handleElement
          ) {

            continue;

          }


          const text =
            cleanText(
              element.innerText ||
              element.textContent
            );


          if (
            !looksLikeUsableScreenName(
              text
            )
          ) {

            continue;

          }


          let rect;


          try {

            rect =
              element
                .getBoundingClientRect();

          } catch {

            continue;

          }


          const verticalDistance =
            handleRect.top -
            rect.bottom;


          const horizontalDistance =
            Math.abs(
              rect.left -
              handleRect.left
            );


          if (
            verticalDistance <
              -12 ||
            verticalDistance >
              110 ||
            horizontalDistance >
              220
          ) {

            continue;

          }


          let fontSize =
            0;


          let fontWeight =
            400;


          try {

            const style =
              doc.defaultView
                .getComputedStyle(
                  element
                );


            fontSize =
              parseFloat(
                style.fontSize
              ) ||
              0;


            const parsed =
              parseInt(
                style.fontWeight,
                10
              );


            if (
              Number.isFinite(
                parsed
              )
            ) {

              fontWeight =
                parsed;

            }

          } catch {}


          let score =
            0;


          score +=
            Math.max(
              0,
              130 -
              Math.abs(
                verticalDistance
              ) *
              2
            );


          score +=
            Math.max(
              0,
              70 -
              horizontalDistance
            );


          if (
            fontSize >=
              24
          ) {

            score +=
              80;

          } else if (
            fontSize >=
              19
          ) {

            score +=
              50;

          }


          if (
            fontWeight >=
              700
          ) {

            score +=
              45;

          }


          candidates.push(
            {
              text,
              score
            }
          );

        }

      }


      candidates.sort(
        (a, b) =>
          b.score -
          a.score
      );


      if (
        candidates.length
      ) {

        return candidates[0]
          .text;

      }

    }


    return "";

  }


  const AUTO_SCREEN_NAME =
    detectScreenNameFromProfile(
      document
    );


  /* ============================================================
     REMOVE PREVIOUS UI
     ============================================================ */

  for (
    const id of [
      "clank-scene-collector-v7",
      "clank-scene-collector-v6",
      "clank-scene-collector-v5",
      "clank-scene-collector-final",
      "clank-dynamic-scene-collector"
    ]
  ) {

    document.getElementById(
      id
    )?.remove();

  }


  /* ============================================================
     STATE
     ============================================================ */

  let worker =
    null;


  let cancelled =
    false;


  let phase =
    "idle";


  let EXPECTED_SCREEN_NAME =
    AUTO_SCREEN_NAME;


  let DISCOVERED_CHARACTERS =
    [];


  let CHARACTERS =
    [];


  let results =
    [];


  let errors =
    [];


  /* ============================================================
     PROFILE URLS INSIDE AN ELEMENT
     ============================================================ */

  function userProfileUrlsInside(
    container
  ) {

    if (!container) {

      return [];

    }


    const found =
      new Set();


    for (
      const element of [
        ...container.querySelectorAll(
          [
            "a[href]",
            "[data-href]",
            "[data-url]",
            "[data-path]",
            "[to]"
          ].join(",")
        )
      ]
    ) {

      const values =
        [
          element.getAttribute(
            "href"
          ),

          element.getAttribute(
            "data-href"
          ),

          element.getAttribute(
            "data-url"
          ),

          element.getAttribute(
            "data-path"
          ),

          element.getAttribute(
            "to"
          )
        ]
          .filter(
            Boolean
          );


      for (
        const value of values
      ) {

        const normalized =
          normalizeUserProfileUrl(
            value
          );


        if (
          normalized
        ) {

          found.add(
            normalized
          );

        }

      }

    }


    return [
      ...found
    ];

  }


  /* ============================================================
     CREATOR BYLINES
     ============================================================ */

  function getCreatorBylines(
    container,
    type
  ) {

    if (!container) {

      return [];

    }


    const regex =
      type ===
        "modal"
        ? /^created\s+by\s+(.+?)\s*$/i
        : /^by\s+(.+?)\s*$/i;


    const found =
      [];


    for (
      const element of [
        container,
        ...container.querySelectorAll(
          "div,span,p,strong,b,a"
        )
      ]
    ) {

      let text;


      try {

        text =
          cleanText(
            element.innerText ||
            element.textContent
          );

      } catch {

        continue;

      }


      if (
        !text ||
        text.length >
          120
      ) {

        continue;

      }


      const match =
        text.match(
          regex
        );


      if (!match) {

        continue;

      }


      let rect;


      try {

        rect =
          element
            .getBoundingClientRect();

      } catch {

        rect =
          null;

      }


      if (
        rect &&
        rect.height >
          110
      ) {

        continue;

      }


      const name =
        cleanText(
          match[1]
        );


      if (!name) {

        continue;

      }


      found.push(
        {

          name,

          profileUrls:
            userProfileUrlsInside(
              element
            )

        }
      );

    }


    const seen =
      new Set();


    return found.filter(
      item => {

        const key =
          normalizedName(
            item.name
          ) +
          "||" +
          item.profileUrls
            .slice()
            .sort()
            .join("|");


        if (
          seen.has(
            key
          )
        ) {

          return false;

        }


        seen.add(
          key
        );


        return true;

      }
    );

  }


  /* ============================================================
     CREATOR VERIFICATION
     ============================================================ */

  function creatorMatchesExpected(
    container,
    type
  ) {

    const expectedName =
      normalizedName(
        EXPECTED_SCREEN_NAME
      );


    if (
      !expectedName
    ) {

      return false;

    }


    const bylines =
      getCreatorBylines(
        container,
        type
      );


    for (
      const byline of bylines
    ) {

      if (
        normalizedName(
          byline.name
        ) !==
        expectedName
      ) {

        continue;

      }


      /*
      If Clank exposes a user-profile URL inside this byline,
      it must match the profile that launched the collector.
      */

      if (
        byline.profileUrls
          .length >
        0
      ) {

        if (
          !byline.profileUrls
            .includes(
              USER_PROFILE_URL_NORMALIZED
            )
        ) {

          continue;

        }

      }


      return true;

    }


    return false;

  }


  /* ============================================================
     PAGE WAIT
     ============================================================ */

  async function waitForPage(
    popup,
    predicate,
    timeout =
      30000
  ) {

    const started =
      Date.now();


    while (
      Date.now() -
      started <
      timeout
    ) {

      if (
        cancelled
      ) {

        throw new Error(
          "Cancelled"
        );

      }


      if (
        !popup ||
        popup.closed
      ) {

        throw new Error(
          "Worker window was closed."
        );

      }


      try {

        if (
          popup.document
            .readyState ===
            "complete" &&
          predicate(
            popup
          )
        ) {

          await sleep(
            PAGE_LOAD_DELAY
          );


          return true;

        }

      } catch {}


      await sleep(
        150
      );

    }


    return false;

  }


  /* ============================================================
     CHARACTER REFERENCE
     ============================================================ */

  function parseCharacterReference(
    value
  ) {

    if (!value) {

      return null;

    }


    const match =
      String(
        value
      ).match(
        /(?:https?:\/\/(?:www\.)?clank\.world)?\/?@c\/([A-Za-z0-9_.%\-]+)/i
      );


    if (!match) {

      return null;

    }


    let handle;


    try {

      handle =
        decodeURIComponent(
          match[1]
        );

    } catch {

      handle =
        match[1];

    }


    return {

      handle,

      url:
        `https://www.clank.world/@c/${encodeURIComponent(
          handle
        )}`

    };

  }


  /* ============================================================
     /your-characters CARD
     ============================================================ */

  function findYourCharacterCard(
    sourceElement,
    handle
  ) {

    let node =
      sourceElement;


    let best =
      null;


    let bestScore =
      -Infinity;


    const handlePattern =
      new RegExp(
        "@c/" +
        escapeRegExp(
          handle
        ),
        "i"
      );


    for (
      let depth = 0;
      depth <
        14 &&
      node &&
      node !==
        node.ownerDocument.body;
      depth++,
      node =
        node.parentElement
    ) {

      let rect;


      try {

        rect =
          node
            .getBoundingClientRect();

      } catch {

        continue;

      }


      if (
        rect.width <
          150 ||
        rect.width >
          700 ||
        rect.height <
          170 ||
        rect.height >
          1300
      ) {

        continue;

      }


      const text =
        cleanText(
          node.innerText
        );


      if (
        !handlePattern.test(
          text
        )
      ) {

        continue;

      }


      let score =
        0;


      if (
        rect.width >=
          180 &&
        rect.width <=
          360
      ) {

        score +=
          50;

      }


      if (
        /Start chat/i.test(
          text
        )
      ) {

        score +=
          30;

      }


      if (
        /Continue chat/i.test(
          text
        )
      ) {

        score +=
          15;

      }


      if (
        /\bEdit\b/i.test(
          text
        )
      ) {

        score +=
          30;

      }


      if (
        node.querySelector(
          "img"
        )
      ) {

        score +=
          10;

      }


      score -=
        (
          rect.width *
          rect.height
        ) /
        100000;


      if (
        score >
        bestScore
      ) {

        bestScore =
          score;


        best =
          node;

      }

    }


    return best;

  }


  /* ============================================================
     CHARACTER DISPLAY NAME
     ============================================================ */

  function inferYourCharacterName(
    card,
    handle
  ) {

    if (!card) {

      return handle;

    }


    const lines =
      String(
        card.innerText ||
        ""
      )
        .split(
          "\n"
        )
        .map(
          cleanText
        )
        .filter(
          Boolean
        );


    const exactHandle =
      `@c/${handle}`
        .toLocaleLowerCase();


    const handleIndex =
      lines.findIndex(
        line =>
          line
            .toLocaleLowerCase() ===
          exactHandle
      );


    if (
      handleIndex >
      0
    ) {

      for (
        let i =
          handleIndex -
          1;
        i >=
        0;
        i--
      ) {

        const line =
          lines[i];


        if (
          !line ||
          line.length >
            120
        ) {

          continue;

        }


        if (
          /^(public|private|start chat|continue chat|edit|add items)$/i.test(
            line
          )
        ) {

          continue;

        }


        return line;

      }

    }


    return handle;

  }


  /* ============================================================
     SNAPSHOT /your-characters
     ============================================================ */

  function collectYourCharactersSnapshot(
    doc,
    discovered
  ) {

    function addCharacter(
      parsed,
      sourceElement
    ) {

      if (!parsed) {

        return;

      }


      const normalizedUrl =
        normalizePathUrl(
          parsed.url
        );


      if (!normalizedUrl) {

        return;

      }


      const card =
        sourceElement
          ? findYourCharacterCard(
              sourceElement,
              parsed.handle
            )
          : null;


      const name =
        inferYourCharacterName(
          card,
          parsed.handle
        );


      if (
        !discovered.has(
          normalizedUrl
        )
      ) {

        discovered.set(
          normalizedUrl,
          {

            key:
              parsed.handle
                .toLocaleLowerCase(),

            handle:
              parsed.handle,

            name,

            url:
              parsed.url,

            allowHiddenScenes:
              false

          }
        );

      } else {

        const existing =
          discovered.get(
            normalizedUrl
          );


        if (
          normalizedName(
            existing.name
          ) ===
            normalizedName(
              existing.handle
            ) &&
          normalizedName(
            name
          ) !==
            normalizedName(
              parsed.handle
            )
        ) {

          existing.name =
            name;

        }

      }

    }


    /*
    Route attributes.
    */

    for (
      const element of [
        ...doc.querySelectorAll(
          [
            "a[href]",
            "[data-href]",
            "[data-url]",
            "[data-path]",
            "[to]"
          ].join(",")
        )
      ]
    ) {

      const values =
        [
          element.getAttribute(
            "href"
          ),

          element.getAttribute(
            "data-href"
          ),

          element.getAttribute(
            "data-url"
          ),

          element.getAttribute(
            "data-path"
          ),

          element.getAttribute(
            "to"
          )
        ]
          .filter(
            Boolean
          );


      for (
        const value of values
      ) {

        addCharacter(
          parseCharacterReference(
            value
          ),
          element
        );

      }

    }


    /*
    Exact visible @c/handle text.
    */

    for (
      const element of [
        ...doc.querySelectorAll(
          "a,span,div,p"
        )
      ]
    ) {

      if (
        element.children.length >
        2
      ) {

        continue;

      }


      const text =
        cleanText(
          element.innerText ||
          element.textContent
        );


      if (
        !/^@c\/[A-Za-z0-9_.%\-]+$/i.test(
          text
        )
      ) {

        continue;

      }


      addCharacter(
        parseCharacterReference(
          text
        ),
        element
      );

    }

  }


  /* ============================================================
     DISCOVER CHARACTERS

     IMPORTANT:
     NO CREATOR CHECK DURING THIS INITIAL STAGE.
     ============================================================ */

  async function discoverYourCharacters(
    popup
  ) {

    status.textContent =
      "Stage 1/2 — Opening /your-characters…";


    popup.location.href =
      YOUR_CHARACTERS_URL;


    const loaded =
      await waitForPage(
        popup,
        currentPopup => {

          try {

            return (
              new URL(
                currentPopup
                  .location
                  .href
              ).pathname ===
              "/your-characters"
            );

          } catch {

            return false;

          }

        }
      );


    if (!loaded) {

      throw new Error(
        "Could not load /your-characters. Make sure you are signed into Clank."
      );

    }


    console.log(
      "%c/your-characters LOADED",
      "color:#67e493;font-weight:bold"
    );


    console.log(
      "Creator verification intentionally skipped ONLY during this stage."
    );


    const discovered =
      new Map();


    popup.scrollTo(
      0,
      0
    );


    await sleep(
      300
    );


    let previousHeight =
      0;


    let stableBottomPasses =
      0;


    for (
      let pass = 0;
      pass <
        MAX_CHARACTER_SCROLL_PASSES;
      pass++
    ) {

      if (
        cancelled
      ) {

        throw new Error(
          "Cancelled"
        );

      }


      const doc =
        popup.document;


      collectYourCharactersSnapshot(
        doc,
        discovered
      );


      status.textContent =
        `Stage 1/2 — Discovering characters… ${discovered.size} found`;


      progressBar.style.width =
        `${Math.min(
          45,
          Math.round(
            (
              pass /
              MAX_CHARACTER_SCROLL_PASSES
            ) *
            45
          )
        )}%`;


      const viewportHeight =
        Math.max(
          popup.innerHeight ||
          700,
          400
        );


      const pageHeight =
        Math.max(
          doc.body
            ?.scrollHeight ||
            0,
          doc.documentElement
            ?.scrollHeight ||
            0
        );


      const nextY =
        Math.min(
          popup.scrollY +
          viewportHeight *
          0.78,
          pageHeight
        );


      popup.scrollTo(
        0,
        nextY
      );


      await sleep(
        SCROLL_DELAY
      );


      const newHeight =
        Math.max(
          doc.body
            ?.scrollHeight ||
            0,
          doc.documentElement
            ?.scrollHeight ||
            0
        );


      const nearBottom =
        (
          popup.scrollY +
          popup.innerHeight
        ) >=
        (
          newHeight -
          80
        );


      if (
        nearBottom &&
        Math.abs(
          newHeight -
          previousHeight
        ) <
        10
      ) {

        stableBottomPasses++;

      } else {

        stableBottomPasses =
          0;

      }


      previousHeight =
        newHeight;


      if (
        stableBottomPasses >=
        3
      ) {

        break;

      }

    }


    collectYourCharactersSnapshot(
      popup.document,
      discovered
    );


    popup.scrollTo(
      0,
      0
    );


    let characters =
      [
        ...discovered.values()
      ];


    if (
      TEST_ONLY
    ) {

      const needle =
        normalizedName(
          TEST_ONLY
        );


      characters =
        characters.filter(
          character => {

            return (

              normalizedName(
                character.handle
              ) ===
                needle ||

              normalizedName(
                character.name
              ) ===
                needle ||

              character.url
                .toLocaleLowerCase()
                .includes(
                  needle
                )

            );

          }
        );

    }


    characters.sort(
      (a, b) =>
        a.name.localeCompare(
          b.name
        )
    );


    if (
      characters.length ===
      0
    ) {

      throw new Error(
        "No @c/... characters were discovered."
      );

    }


    console.log(
      `%cDISCOVERED ${characters.length} CHARACTERS`,
      "color:#78b7ff;font-weight:bold"
    );


    console.table(
      characters.map(
        (
          character,
          index
        ) => ({

          "#":
            index +
            1,

          name:
            character.name,

          handle:
            character.handle,

          url:
            character.url

        })
      )
    );


    return characters;

  }


  /* ============================================================
     CHARACTER SELECTION UI
     ============================================================ */

  function renderCharacterPicker() {

    pickerElement.hidden =
      false;


    const rows =
      DISCOVERED_CHARACTERS
        .map(
          (
            character,
            index
          ) => `

<div
  class="character-row"
  data-index="${index}"
  data-search="${escapeHtml(
    (
      character.name +
      " " +
      character.handle
    ).toLocaleLowerCase()
  )}"
>

  <div class="character-main">

    <label class="scan-label">

      <input
        type="checkbox"
        class="scan-character"
        data-index="${index}"
        checked
      >

      <span>

        <b>
          ${escapeHtml(character.name)}
        </b>

        <small>
          @c/${escapeHtml(character.handle)}
        </small>

      </span>

    </label>

  </div>


  <label class="hidden-label">

    <input
      type="checkbox"
      class="allow-hidden"
      data-index="${index}"
    >

    <span>
      Allow hidden/private scenes
    </span>

  </label>

</div>

`
        )
        .join("");


    pickerElement.innerHTML = `

<div class="picker-header">

  <b>
    Choose characters to scan
  </b>

  <div class="picker-sub">

    ${DISCOVERED_CHARACTERS.length}
    characters discovered from /your-characters.

  </div>

</div>


<input
  class="character-filter"
  type="text"
  placeholder="Filter characters..."
>


<div class="picker-tools">

  <button
    type="button"
    class="select-all"
  >
    Select All
  </button>

  <button
    type="button"
    class="select-none"
  >
    Select None
  </button>

  <button
    type="button"
    class="invert-selection"
  >
    Invert
  </button>

</div>


<div class="picker-tools">

  <button
    type="button"
    class="allow-hidden-selected"
  >
    Allow Hidden for Selected
  </button>

  <button
    type="button"
    class="disallow-hidden"
  >
    Disallow Hidden for All
  </button>

</div>


<div class="selection-summary"></div>


<div class="character-list">

  ${rows}

</div>


<div class="picker-footer">

  <button
    type="button"
    class="scan-selected primary"
  >
    Scan Selected Characters
  </button>

</div>

`;


    const filterInput =
      pickerElement.querySelector(
        ".character-filter"
      );


    const rowsElements =
      [
        ...pickerElement.querySelectorAll(
          ".character-row"
        )
      ];


    const scanInputs =
      () =>
        [
          ...pickerElement.querySelectorAll(
            ".scan-character"
          )
        ];


    const hiddenInputs =
      () =>
        [
          ...pickerElement.querySelectorAll(
            ".allow-hidden"
          )
        ];


    function updateSelectionUI() {

      const scans =
        scanInputs();


      const hiddens =
        hiddenInputs();


      let selectedCount =
        0;


      let hiddenCount =
        0;


      for (
        const scan of scans
      ) {

        const index =
          Number(
            scan.dataset.index
          );


        const hidden =
          pickerElement.querySelector(
            `.allow-hidden[data-index="${index}"]`
          );


        const row =
          pickerElement.querySelector(
            `.character-row[data-index="${index}"]`
          );


        if (
          scan.checked
        ) {

          selectedCount++;


          row?.classList
            .remove(
              "not-selected"
            );


          if (
            hidden
          ) {

            hidden.disabled =
              false;


            if (
              hidden.checked
            ) {

              hiddenCount++;


              row?.classList
                .add(
                  "hidden-enabled"
                );

            } else {

              row?.classList
                .remove(
                  "hidden-enabled"
                );

            }

          }

        } else {

          row?.classList
            .add(
              "not-selected"
            );


          row?.classList
            .remove(
              "hidden-enabled"
            );


          if (
            hidden
          ) {

            hidden.disabled =
              true;

          }

        }

      }


      pickerElement
        .querySelector(
          ".selection-summary"
        )
        .innerHTML = `

<b>${selectedCount}</b>
of
<b>${DISCOVERED_CHARACTERS.length}</b>
characters selected

&nbsp;•&nbsp;

<b>${hiddenCount}</b>
selected character${hiddenCount === 1 ? "" : "s"}
allow hidden/private scenes

`;

    }


    for (
      const scan of scanInputs()
    ) {

      scan.addEventListener(
        "change",
        updateSelectionUI
      );

    }


    for (
      const hidden of hiddenInputs()
    ) {

      hidden.addEventListener(
        "change",
        updateSelectionUI
      );

    }


    filterInput.addEventListener(
      "input",
      () => {

        const needle =
          normalizedName(
            filterInput.value
          );


        for (
          const row of rowsElements
        ) {

          const haystack =
            row.dataset.search ||
            "";


          row.hidden =
            Boolean(
              needle &&
              !haystack.includes(
                needle
              )
            );

        }

      }
    );


    pickerElement
      .querySelector(
        ".select-all"
      )
      .addEventListener(
        "click",
        () => {

          for (
            const input of scanInputs()
          ) {

            input.checked =
              true;

          }


          updateSelectionUI();

        }
      );


    pickerElement
      .querySelector(
        ".select-none"
      )
      .addEventListener(
        "click",
        () => {

          for (
            const input of scanInputs()
          ) {

            input.checked =
              false;

          }


          updateSelectionUI();

        }
      );


    pickerElement
      .querySelector(
        ".invert-selection"
      )
      .addEventListener(
        "click",
        () => {

          for (
            const input of scanInputs()
          ) {

            input.checked =
              !input.checked;

          }


          updateSelectionUI();

        }
      );


    pickerElement
      .querySelector(
        ".allow-hidden-selected"
      )
      .addEventListener(
        "click",
        () => {

          for (
            const scan of scanInputs()
          ) {

            if (
              !scan.checked
            ) {

              continue;

            }


            const hidden =
              pickerElement.querySelector(
                `.allow-hidden[data-index="${scan.dataset.index}"]`
              );


            if (
              hidden
            ) {

              hidden.checked =
                true;

            }

          }


          updateSelectionUI();

        }
      );


    pickerElement
      .querySelector(
        ".disallow-hidden"
      )
      .addEventListener(
        "click",
        () => {

          for (
            const hidden of hiddenInputs()
          ) {

            hidden.checked =
              false;

          }


          updateSelectionUI();

        }
      );


    pickerElement
      .querySelector(
        ".scan-selected"
      )
      .addEventListener(
        "click",
        beginSelectedScan
      );


    updateSelectionUI();

  }


  function getSelectedCharactersFromPicker() {

    const selected =
      [];


    for (
      const character of DISCOVERED_CHARACTERS
    ) {

      const index =
        DISCOVERED_CHARACTERS
          .indexOf(
            character
          );


      const scan =
        pickerElement.querySelector(
          `.scan-character[data-index="${index}"]`
        );


      const hidden =
        pickerElement.querySelector(
          `.allow-hidden[data-index="${index}"]`
        );


      if (
        !scan?.checked
      ) {

        continue;

      }


      selected.push(
        {

          ...character,

          allowHiddenScenes:
            Boolean(
              hidden?.checked
            )

        }
      );

    }


    return selected;

  }


  function lockCharacterPicker() {

    for (
      const input of pickerElement
        .querySelectorAll(
          "input,button"
        )
    ) {

      input.disabled =
        true;

    }


    pickerElement
      .classList
      .add(
        "picker-locked"
      );

  }


  /* ============================================================
     SEARCH URL
     ============================================================ */

  function searchUrlFor(
    character
  ) {

    return (
      "https://www.clank.world/search?q=" +
      encodeURIComponent(
        "@c/" +
        character.handle
      )
    );

  }


  /* ============================================================
     SCENE URL
     ============================================================ */

  function getSceneId(
    value
  ) {

    try {

      const url =
        new URL(
          value
        );


      return (
        url.searchParams.get(
          "scene"
        ) ||
        null
      );

    } catch {

      return null;

    }

  }


  function isSceneUrl(
    value
  ) {

    return Boolean(
      getSceneId(
        value
      )
    );

  }


  function isCleanSearchUrl(
    value,
    expectedSearch
  ) {

    try {

      const current =
        new URL(
          value
        );


      const expected =
        new URL(
          expectedSearch
        );


      return (

        current.hostname.endsWith(
          "clank.world"
        ) &&

        current.pathname ===
          "/search" &&

        !current.searchParams.has(
          "scene"
        ) &&

        current.searchParams.get(
          "q"
        ) ===
          expected.searchParams.get(
            "q"
          )

      );

    } catch {

      return false;

    }

  }


  /* ============================================================
     LOAD SEARCH
     ============================================================ */

  async function loadCharacterSearch(
    popup,
    searchUrl
  ) {

    try {

      popup.location.replace(
        searchUrl
      );

    } catch {

      popup.location.href =
        searchUrl;

    }


    const loaded =
      await waitForPage(
        popup,
        currentPopup =>
          isCleanSearchUrl(
            currentPopup
              .location
              .href,
            searchUrl
          )
      );


    if (!loaded) {

      return false;

    }


    let previousHeight =
      0;


    let stable =
      0;


    for (
      let pass = 0;
      pass <
        MAX_SEARCH_SCROLL_PASSES;
      pass++
    ) {

      const doc =
        popup.document;


      const height =
        Math.max(
          doc.body
            ?.scrollHeight ||
            0,
          doc.documentElement
            ?.scrollHeight ||
            0
        );


      popup.scrollTo(
        0,
        height
      );


      await sleep(
        400
      );


      const newHeight =
        Math.max(
          doc.body
            ?.scrollHeight ||
            0,
          doc.documentElement
            ?.scrollHeight ||
            0
        );


      if (
        newHeight <=
        previousHeight +
        5
      ) {

        stable++;

      } else {

        stable =
          0;

      }


      previousHeight =
        newHeight;


      if (
        stable >=
        2
      ) {

        break;

      }

    }


    popup.scrollTo(
      0,
      0
    );


    await sleep(
      300
    );


    return true;

  }


  /* ============================================================
     SEARCH RESULT CARD
     ============================================================ */

  function findSceneCardAncestor(
    image
  ) {

    let node =
      image;


    let best =
      null;


    let bestScore =
      -Infinity;


    for (
      let depth = 0;
      depth <
        12 &&
      node &&
      node !==
        node.ownerDocument.body;
      depth++,
      node =
        node.parentElement
    ) {

      let rect;


      try {

        rect =
          node
            .getBoundingClientRect();

      } catch {

        continue;

      }


      if (
        rect.width <
          100 ||
        rect.width >
          460 ||
        rect.height <
          140 ||
        rect.height >
          780
      ) {

        continue;

      }


      const text =
        cleanText(
          node.innerText
        );


      if (
        text.length <
          5 ||
        text.length >
          6000
      ) {

        continue;

      }


      const imageCount =
        node.querySelectorAll(
          "img"
        ).length;


      if (
        imageCount >
        6
      ) {

        continue;

      }


      const bylines =
        getCreatorBylines(
          node,
          "search"
        );


      if (
        bylines.length ===
        0
      ) {

        continue;

      }


      let score =
        0;


      if (
        rect.width >=
          115 &&
        rect.width <=
          310
      ) {

        score +=
          40;

      }


      if (
        rect.height >=
          170 &&
        rect.height <=
          640
      ) {

        score +=
          35;

      }


      if (
        imageCount ===
        1
      ) {

        score +=
          20;

      }


      if (
        bylines.length ===
        1
      ) {

        score +=
          20;

      }


      score -=
        (
          rect.width *
          rect.height
        ) /
        150000;


      if (
        score >
        bestScore
      ) {

        bestScore =
          score;


        best =
          node;

      }

    }


    return best;

  }


  /* ============================================================
     CORRECT IMAGE URL EXTRACTION

     IMPORTANT:
     currentSrc FIRST.

     Do NOT parse Clank srcset by splitting commas.
     ============================================================ */

  function getBestImageUrl(
    image
  ) {

    if (!image) {

      return "";

    }


    const candidates =
      [
        image.currentSrc,
        image.src,
        image.getAttribute(
          "src"
        ),
        image.getAttribute(
          "data-src"
        ),
        image.getAttribute(
          "data-original"
        ),
        image.getAttribute(
          "data-image"
        ),
        image.getAttribute(
          "data-image-src"
        )
      ];


    for (
      const candidate of candidates
    ) {

      const value =
        cleanText(
          candidate ||
          ""
        );


      if (
        !value ||
        /^data:/i.test(
          value
        ) ||
        /^blob:/i.test(
          value
        )
      ) {

        continue;

      }


      try {

        const url =
          new URL(
            value,
            image.ownerDocument
              ?.location
              ?.href ||
            "https://www.clank.world/"
          );


        if (
          /^https?:$/i.test(
            url.protocol
          )
        ) {

          return url.href;

        }

      } catch {}

    }


    return "";

  }


  /* ============================================================
     SEARCH CARD MESSAGE COUNT / POPULARITY
     ============================================================ */

  function parseCompactMessageCount(
    value
  ) {

    const text =
      cleanText(
        value
      )
        .replace(
          /,/g,
          ""
        );


    if (!text) {

      return null;

    }


    /*
    Accept the forms Clank currently displays on search cards:

      57
      4.7K
      62.6K
      172K
      1.2M
      3B

    Also tolerate a short label such as "62.6K messages".
    */

    const match =
      text.match(
        /^(?:[^0-9]{0,4})?(\d+(?:\.\d+)?)\s*([KMB])?(?:\s*(?:messages?|msgs?|chats?))?$/i
      );


    if (!match) {

      return null;

    }


    const number =
      Number(
        match[1]
      );


    if (
      !Number.isFinite(
        number
      )
    ) {

      return null;

    }


    const suffix =
      String(
        match[2] || ""
      )
        .toUpperCase();


    const multiplier =
      suffix === "B"
        ? 1_000_000_000
        : suffix === "M"
          ? 1_000_000
          : suffix === "K"
            ? 1_000
            : 1;


    return {

      display:
        match[1] + suffix,

      value:
        Math.round(
          number *
          multiplier
        )

    };

  }


  function getSearchCardMessageCount(
    card
  ) {

    if (!card) {

      return {
        display: "",
        value: null
      };

    }


    let cardRect =
      null;


    try {

      cardRect =
        card.getBoundingClientRect();

    } catch {}


    const candidates =
      [];


    const elements =
      [
        ...card.querySelectorAll(
          "span,div,p,strong,b,a"
        )
      ];


    for (
      const element of elements
    ) {

      if (
        element.children.length >
        3
      ) {

        continue;

      }


      let rect =
        null;


      try {

        rect =
          element.getBoundingClientRect();

      } catch {}


      if (
        rect &&
        (
          rect.width <= 0 ||
          rect.height <= 0
        )
      ) {

        continue;

      }


      const values =
        [
          element.innerText,
          element.textContent,
          element.getAttribute?.(
            "aria-label"
          ),
          element.getAttribute?.(
            "title"
          )
        ]
          .filter(
            Boolean
          );


      for (
        const raw of values
      ) {

        const parsed =
          parseCompactMessageCount(
            raw
          );


        if (!parsed) {

          continue;

        }


        let score =
          0;


        const lower =
          normalizedName(
            raw
          );


        if (
          /messages?|msgs?|chats?/.test(
            lower
          )
        ) {

          score +=
            300;

        }


        if (
          cardRect &&
          rect
        ) {

          const topDistance =
            Math.abs(
              rect.top -
              cardRect.top
            );


          if (
            topDistance <=
            70
          ) {

            score +=
              180;

          }


          if (
            rect.left >=
            cardRect.left +
            cardRect.width *
            0.45
          ) {

            score +=
              120;

          }


          score -=
            Math.min(
              120,
              topDistance
            );

        }


        /*
        A compact K/M/B value is much more likely to be the card's message
        counter than a bare integer appearing somewhere in the description.
        */

        if (
          /[KMB]/i.test(
            parsed.display
          )
        ) {

          score +=
            100;

        }


        candidates.push(
          {
            ...parsed,
            score
          }
        );

      }

    }


    if (
      candidates.length ===
      0
    ) {

      /*
      Fallback: the count is normally among the first few short lines of the
      card, next to the character name.
      */

      const earlyLines =
        String(
          card.innerText ||
          ""
        )
          .split(
            "\n"
          )
          .map(
            cleanText
          )
          .filter(
            Boolean
          )
          .slice(
            0,
            6
          );


      for (
        const line of earlyLines
      ) {

        const parsed =
          parseCompactMessageCount(
            line
          );


        if (
          parsed
        ) {

          candidates.push(
            {
              ...parsed,
              score:
                /[KMB]/i.test(
                  parsed.display
                )
                  ? 100
                  : 0
            }
          );

        }

      }

    }


    candidates.sort(
      (a, b) =>
        b.score -
        a.score
    );


    const best =
      candidates[0];


    return best
      ? {
          display:
            best.display,
          value:
            best.value
        }
      : {
          display: "",
          value: null
        };

  }


  /* ============================================================
     VERIFIED SEARCH CARDS
     ============================================================ */

  function collectVerifiedSearchCards(
    doc
  ) {

    const root =
      doc.querySelector(
        "main"
      ) ||

      doc.querySelector(
        '[role="main"]'
      ) ||

      doc.body;


    const found =
      new Map();


    for (
      const image of [
        ...root.querySelectorAll(
          "img"
        )
      ]
    ) {

      let imageRect;


      try {

        imageRect =
          image
            .getBoundingClientRect();

      } catch {

        continue;

      }


      if (
        imageRect.width <
          60 ||
        imageRect.height <
          45
      ) {

        continue;

      }


      const card =
        findSceneCardAncestor(
          image
        );


      if (!card) {

        continue;

      }


      /*
      Creator check is active here.
      */

      if (
        !creatorMatchesExpected(
          card,
          "search"
        )
      ) {

        continue;

      }


      const rect =
        card
          .getBoundingClientRect();


      found.set(
        card,
        {

          card,

          image,

          text:
            cleanText(
              card.innerText
            ),

          searchImageUrl:
            getBestImageUrl(
              image
            ),

          messageCount:
            getSearchCardMessageCount(
              card
            ),

          top:
            rect.top +
            doc.defaultView
              .scrollY,

          left:
            rect.left

        }
      );

    }


    let cards =
      [
        ...found.values()
      ];


    /*
    Remove outer wrappers.
    */

    cards =
      cards.filter(
        candidate => {

          return !cards.some(
            other =>
              candidate !==
                other &&
              candidate.card
                .contains(
                  other.card
                )
          );

        }
      );


    cards.sort(
      (a, b) => {

        if (
          Math.abs(
            a.top -
            b.top
          ) >
          50
        ) {

          return (
            a.top -
            b.top
          );

        }


        return (
          a.left -
          b.left
        );

      }
    );


    return cards;

  }


  /* ============================================================
     SEARCH CARD FALLBACK TITLE
     ============================================================ */

  function getCardFallbackTitle(
    cardInfo,
    characterName
  ) {

    let lines =
      String(
        cardInfo.card
          .innerText ||
        ""
      )
        .split(
          "\n"
        )
        .map(
          cleanText
        )
        .filter(
          Boolean
        );


    /*
    Remove ONE leading occurrence of the character name.
    */

    const expectedCharacter =
      normalizedName(
        characterName
      );


    const nameIndex =
      lines.findIndex(
        line =>
          normalizedName(
            line
          ) ===
          expectedCharacter
      );


    if (
      nameIndex >=
      0
    ) {

      lines.splice(
        nameIndex,
        1
      );

    }


    for (
      const line of lines
    ) {

      if (
        /^by\s+/i.test(
          line
        )
      ) {

        continue;

      }


      if (
        /^#[A-Za-z0-9]/.test(
          line
        )
      ) {

        continue;

      }


      if (
        /^\d+(?:\.\d+)?[kKmMbB]?$/.test(
          line
        )
      ) {

        continue;

      }


      if (
        /^\d+(?:\.\d+)?[kKmMbB]?\s*(?:messages?|msgs?|views?|likes?|comments?|chats?)$/i.test(
          line
        )
      ) {

        continue;

      }


      if (
        line.length >=
          2 &&
        line.length <=
          220
      ) {

        return line;

      }

    }


    return "Scene";

  }


  /* ============================================================
     CLICK SCENE
     ============================================================ */

  function dispatchClick(
    popup,
    x,
    y
  ) {

    const target =
      popup.document
        .elementFromPoint(
          x,
          y
        );


    if (!target) {

      return false;

    }


    const options =
      {

        bubbles:
          true,

        cancelable:
          true,

        composed:
          true,

        view:
          popup,

        clientX:
          x,

        clientY:
          y,

        button:
          0

      };


    for (
      const type of [
        "mousedown",
        "mouseup",
        "click"
      ]
    ) {

      try {

        target.dispatchEvent(
          new popup.MouseEvent(
            type,
            options
          )
        );

      } catch {}

    }


    return true;

  }


  async function waitForSceneUrl(
    popup,
    timeout =
      SCENE_TIMEOUT
  ) {

    const started =
      Date.now();


    while (
      Date.now() -
      started <
      timeout
    ) {

      if (
        cancelled
      ) {

        throw new Error(
          "Cancelled"
        );

      }


      try {

        if (
          isSceneUrl(
            popup.location.href
          )
        ) {

          return normalizeUrl(
            popup.location.href
          );

        }

      } catch {}


      await sleep(
        70
      );

    }


    return null;

  }


  async function clickSceneCard(
    popup,
    cardInfo
  ) {

    cardInfo.card
      .scrollIntoView(
        {

          behavior:
            "auto",

          block:
            "center",

          inline:
            "center"

        }
      );


    await sleep(
      200
    );


    const points =
      [];


    if (
      cardInfo.image
    ) {

      const imageRect =
        cardInfo.image
          .getBoundingClientRect();


      points.push(
        {

          x:
            imageRect.left +
            imageRect.width /
            2,

          y:
            imageRect.top +
            imageRect.height /
            2

        }
      );

    }


    const rect =
      cardInfo.card
        .getBoundingClientRect();


    points.push(
      {

        x:
          rect.left +
          rect.width /
          2,

        y:
          rect.top +
          rect.height *
          0.44

      }
    );


    points.push(
      {

        x:
          rect.left +
          rect.width /
          2,

        y:
          rect.top +
          rect.height /
          2

      }
    );


    for (
      const point of points
    ) {

      dispatchClick(
        popup,
        point.x,
        point.y
      );


      const sceneUrl =
        await waitForSceneUrl(
          popup,
          1800
        );


      if (
        sceneUrl
      ) {

        return sceneUrl;

      }

    }


    try {

      cardInfo.card
        .click();

    } catch {}


    return await waitForSceneUrl(
      popup,
      1800
    );

  }


  /* ============================================================
     SCENE MODAL
     ============================================================ */

  function getSceneModal(
    doc
  ) {

    let candidates =
      [
        ...doc.querySelectorAll(
          [
            '[role="dialog"]',
            '[aria-modal="true"]',
            "dialog",
            '[class*="modal" i]',
            '[class*="dialog" i]'
          ].join(",")
        )
      ];


    candidates =
      candidates.filter(
        element => {

          try {

            const rect =
              element
                .getBoundingClientRect();


            const style =
              doc.defaultView
                .getComputedStyle(
                  element
                );


            return (

              rect.width >
                350 &&

              rect.height >
                220 &&

              style.display !==
                "none" &&

              style.visibility !==
                "hidden"

            );

          } catch {

            return false;

          }

        }
      );


    /*
    Fallback from the Scene details heading.
    */

    if (
      candidates.length ===
      0
    ) {

      const labels =
        [
          ...doc.querySelectorAll(
            "div,span,h1,h2,h3,strong"
          )
        ]
          .filter(
            element =>
              normalizedName(
                element.innerText ||
                element.textContent
              ) ===
              "scene details"
          );


      for (
        const label of labels
      ) {

        let node =
          label;


        for (
          let depth = 0;
          depth <
            10 &&
          node;
          depth++,
          node =
            node.parentElement
        ) {

          try {

            const rect =
              node
                .getBoundingClientRect();


            if (
              rect.width >
                500 &&
              rect.height >
                300
            ) {

              candidates.push(
                node
              );


              break;

            }

          } catch {}

        }

      }

    }


    candidates.sort(
      (a, b) => {

        const ar =
          a
            .getBoundingClientRect();


        const br =
          b
            .getBoundingClientRect();


        return (
          br.width *
          br.height
        ) - (
          ar.width *
          ar.height
        );

      }
    );


    return (
      candidates[0] ||
      null
    );

  }


  async function waitForSceneModal(
    popup,
    timeout =
      MODAL_TIMEOUT
  ) {

    const started =
      Date.now();


    while (
      Date.now() -
      started <
      timeout
    ) {

      const modal =
        getSceneModal(
          popup.document
        );


      if (
        modal
      ) {

        return modal;

      }


      await sleep(
        100
      );

    }


    return null;

  }


  /* ============================================================
     PUBLIC / PRIVATE
     ============================================================ */

  function getSceneVisibility(
    doc
  ) {

    const modal =
      getSceneModal(
        doc
      );


    if (!modal) {

      return "unknown";

    }


    const elements =
      [
        ...modal.querySelectorAll(
          "div,span,p,strong,b,button"
        )
      ];


    for (
      const element of elements
    ) {

      const text =
        cleanText(
          element.innerText ||
          element.textContent
        );


      if (
        /^public\s+scene$/i.test(
          text
        )
      ) {

        return "public";

      }


      if (
        /^private\s+scene$/i.test(
          text
        )
      ) {

        return "private";

      }

    }


    return "unknown";

  }


  /* ============================================================
     MODAL CREATOR
     ============================================================ */

  function sceneCreatorVerified(
    doc
  ) {

    const modal =
      getSceneModal(
        doc
      );


    if (!modal) {

      return false;

    }


    return creatorMatchesExpected(
      modal,
      "modal"
    );

  }


  /* ============================================================
     OPTIONAL EXACT CHARACTER VERIFICATION
     ============================================================ */

  function verifyExactCharacterIfAvailable(
    doc,
    character
  ) {

    const modal =
      getSceneModal(
        doc
      );


    if (!modal) {

      return {

        available:
          false,

        matches:
          true

      };

    }


    const detected =
      new Set();


    for (
      const element of [
        ...modal.querySelectorAll(
          [
            "a[href]",
            "[data-href]",
            "[data-url]",
            "[data-path]",
            "[to]"
          ].join(",")
        )
      ]
    ) {

      const values =
        [
          element.getAttribute(
            "href"
          ),

          element.getAttribute(
            "data-href"
          ),

          element.getAttribute(
            "data-url"
          ),

          element.getAttribute(
            "data-path"
          ),

          element.getAttribute(
            "to"
          )
        ]
          .filter(
            Boolean
          );


      for (
        const value of values
      ) {

        const parsed =
          parseCharacterReference(
            value
          );


        if (
          parsed
        ) {

          detected.add(
            normalizePathUrl(
              parsed.url
            )
          );

        }

      }

    }


    if (
      detected.size ===
      0
    ) {

      return {

        available:
          false,

        matches:
          true

      };

    }


    const expected =
      normalizePathUrl(
        character.url
      );


    return {

      available:
        true,

      matches:
        detected.has(
          expected
        ),

      detected:
        [
          ...detected
        ]

    };

  }


  /* ============================================================
     CSS IMAGE URL
     ============================================================ */

  function extractBackgroundImageUrl(
    element,
    doc
  ) {

    try {

      const style =
        doc.defaultView
          .getComputedStyle(
            element
          );


      const background =
        style.backgroundImage;


      if (
        !background ||
        background ===
          "none"
      ) {

        return "";

      }


      const match =
        background.match(
          /url\(["']?(.+?)["']?\)/
        );


      if (!match) {

        return "";

      }


      return absoluteUrl(
        match[1],
        doc.location.href
      );

    } catch {

      return "";

    }

  }


  /* ============================================================
     SCENE HERO / TITLE IMAGE
     ============================================================ */

  function getSceneHeroImageCandidate(
    doc
  ) {

    const modal =
      getSceneModal(
        doc
      );


    if (!modal) {

      return null;

    }


    const modalRect =
      modal
        .getBoundingClientRect();


    const candidates =
      [];


    /*
    Actual <img>.
    */

    for (
      const image of [
        ...modal.querySelectorAll(
          "img"
        )
      ]
    ) {

      let rect;


      try {

        rect =
          image
            .getBoundingClientRect();

      } catch {

        continue;

      }


      /*
      Exclude avatars/icons.
      */

      if (
        rect.width <
          160 ||
        rect.height <
          110
      ) {

        continue;

      }


      const centerX =
        rect.left +
        rect.width /
        2;


      /*
      Title image should be in left/main scene column.
      */

      if (
        centerX >
        modalRect.left +
        modalRect.width *
        0.62
      ) {

        continue;

      }


      const url =
        getBestImageUrl(
          image
        );


      if (!url) {

        continue;

      }


      let score =
        rect.width *
        rect.height;


      if (
        rect.top >
        modalRect.top +
        100
      ) {

        score +=
          150000;

      }


      /*
      Prefer upper large image.
      */

      score -=
        Math.max(
          0,
          rect.top -
          modalRect.top
        ) *
        20;


      candidates.push(
        {

          url,

          rect,

          score,

          source:
            "img"

        }
      );

    }


    /*
    CSS background-image fallback.
    */

    for (
      const element of [
        ...modal.querySelectorAll(
          "div,section,figure"
        )
      ]
    ) {

      let rect;


      try {

        rect =
          element
            .getBoundingClientRect();

      } catch {

        continue;

      }


      if (
        rect.width <
          160 ||
        rect.height <
          110
      ) {

        continue;

      }


      const centerX =
        rect.left +
        rect.width /
        2;


      if (
        centerX >
        modalRect.left +
        modalRect.width *
        0.62
      ) {

        continue;

      }


      const url =
        extractBackgroundImageUrl(
          element,
          doc
        );


      if (!url) {

        continue;

      }


      let score =
        rect.width *
        rect.height;


      if (
        rect.top >
        modalRect.top +
        100
      ) {

        score +=
          150000;

      }


      score -=
        Math.max(
          0,
          rect.top -
          modalRect.top
        ) *
        20;


      candidates.push(
        {

          url,

          rect,

          score,

          source:
            "background"

        }
      );

    }


    candidates.sort(
      (a, b) =>
        b.score -
        a.score
    );


    return (
      candidates[0] ||
      null
    );

  }


  function getSceneTitleImageUrl(
    doc,
    fallbackSearchImage =
      ""
  ) {

    const candidate =
      getSceneHeroImageCandidate(
        doc
      );


    if (
      candidate?.url &&
      /^https?:\/\//i.test(
        candidate.url
      )
    ) {

      return candidate.url;

    }


    if (
      fallbackSearchImage &&
      /^https?:\/\//i.test(
        fallbackSearchImage
      )
    ) {

      return fallbackSearchImage;

    }


    return "";

  }


  /* ============================================================
     REAL SCENE TITLE
     ============================================================ */

  function getRealSceneTitle(
    doc,
    fallback =
      "Scene"
  ) {

    const modal =
      getSceneModal(
        doc
      );


    if (!modal) {

      return fallback;

    }


    const modalRect =
      modal
        .getBoundingClientRect();


    /*
    Find Created by row.
    */

    let createdBy =
      null;


    let smallestArea =
      Infinity;


    for (
      const element of [
        ...modal.querySelectorAll(
          "div,span,p,strong,b"
        )
      ]
    ) {

      const text =
        cleanText(
          element.innerText ||
          element.textContent
        );


      if (
        !/^created\s+by\b/i.test(
          text
        )
      ) {

        continue;

      }


      let rect;


      try {

        rect =
          element
            .getBoundingClientRect();

      } catch {

        continue;

      }


      if (
        rect.height >
        110
      ) {

        continue;

      }


      const area =
        rect.width *
        rect.height;


      if (
        area <
        smallestArea
      ) {

        smallestArea =
          area;


        createdBy =
          element;

      }

    }


    const createdRect =
      createdBy
        ? createdBy
            .getBoundingClientRect()
        : null;


    const hero =
      getSceneHeroImageCandidate(
        doc
      );


    const heroRect =
      hero?.rect ||
      null;


    const candidates =
      [];


    for (
      const element of [
        ...modal.querySelectorAll(
          [
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            '[role="heading"]',
            '[class*="title" i]',
            "strong",
            "b",
            "div",
            "p",
            "span"
          ].join(",")
        )
      ]
    ) {

      if (
        element.children.length >
        4
      ) {

        continue;

      }


      const text =
        cleanText(
          element.innerText ||
          element.textContent
        );


      if (
        text.length <
          2 ||
        text.length >
          220
      ) {

        continue;

      }


      const lower =
        normalizedName(
          text
        );


      const junk =
        new Set([
          "scene details",
          "copy link",
          "share",
          "start chat",
          "see character profile",
          "view collection",
          "comments",
          "initial message",
          "public scene",
          "private scene"
        ]);


      if (
        junk.has(
          lower
        )
      ) {

        continue;

      }


      if (
        /^created\s+by\b/i.test(
          text
        ) ||
        /^by\s+/i.test(
          text
        ) ||
        /^#[A-Za-z0-9]/.test(
          text
        )
      ) {

        continue;

      }


      if (
        /^\d+(?:\.\d+)?[kKmMbB]?$/.test(
          text
        ) ||
        /^\d+(?:\.\d+)?[kKmMbB]?\s*(?:messages?|msgs?|views?|likes?|comments?|chats?)$/i.test(
          text
        )
      ) {

        continue;

      }


      if (
        /^(location|specific spot|date|time|weather)\s*:/i.test(
          text
        )
      ) {

        continue;

      }


      let rect;


      try {

        rect =
          element
            .getBoundingClientRect();

      } catch {

        continue;

      }


      const centerX =
        rect.left +
        rect.width /
        2;


      if (
        centerX >
        modalRect.left +
        modalRect.width *
        0.62
      ) {

        continue;

      }


      if (
        rect.top <
        modalRect.top +
        55
      ) {

        continue;

      }


      if (
        createdRect &&
        rect.top <
        createdRect.bottom -
        3
      ) {

        continue;

      }


      if (
        heroRect &&
        rect.bottom >
        heroRect.top +
        8
      ) {

        continue;

      }


      let fontSize =
        0;


      let fontWeight =
        400;


      try {

        const style =
          doc.defaultView
            .getComputedStyle(
              element
            );


        fontSize =
          parseFloat(
            style.fontSize
          ) ||
          0;


        const parsed =
          parseInt(
            style.fontWeight,
            10
          );


        if (
          Number.isFinite(
            parsed
          )
        ) {

          fontWeight =
            parsed;

        }

      } catch {}


      let score =
        0;


      if (
        /^H[1-4]$/.test(
          element.tagName
        )
      ) {

        score +=
          110;

      }


      if (
        fontSize >=
          22
      ) {

        score +=
          105;

      } else if (
        fontSize >=
          19
      ) {

        score +=
          75;

      }


      if (
        fontWeight >=
          700
      ) {

        score +=
          50;

      }


      if (
        text.length <=
        120
      ) {

        score +=
          30;

      }


      if (
        createdRect
      ) {

        const distance =
          rect.top -
          createdRect.bottom;


        if (
          distance >=
            0 &&
          distance <=
            55
        ) {

          score +=
            220;

        } else if (
          distance >=
            0 &&
          distance <=
            110
        ) {

          score +=
            80;

        }

      }


      if (
        heroRect
      ) {

        const distance =
          heroRect.top -
          rect.bottom;


        if (
          distance >=
            0 &&
          distance <=
            55
        ) {

          score +=
            125;

        }

      }


      candidates.push(
        {

          text,

          score

        }
      );

    }


    candidates.sort(
      (a, b) =>
        b.score -
        a.score
    );


    return (
      candidates[0]?.text ||
      fallback
    );

  }


  /* ============================================================
     COLLECT ONE CHARACTER
     ============================================================ */

  async function collectCharacter(
    character,
    characterIndex
  ) {

    const searchUrl =
      searchUrlFor(
        character
      );


    console.group(
      `%c${character.name}`,
      "color:#78b7ff;font-weight:bold"
    );


    console.log(
      "Character:",
      character.url
    );


    console.log(
      "Allow hidden/private scenes:",
      character.allowHiddenScenes
    );


    const loaded =
      await loadCharacterSearch(
        worker,
        searchUrl
      );


    if (!loaded) {

      console.groupEnd();


      throw new Error(
        "Could not load character search."
      );

    }


    let cards =
      collectVerifiedSearchCards(
        worker.document
      );


    const expectedCount =
      cards.length;


    console.log(
      "Creator-matching search cards:",
      expectedCount
    );


    const captured =
      new Map();


    for (
      let cardIndex = 0;
      cardIndex <
        expectedCount;
      cardIndex++
    ) {

      if (
        cancelled
      ) {

        break;

      }


      status.textContent =
        `Stage 2/2 — ${characterIndex + 1}/${CHARACTERS.length} — ${character.name} — scene ${cardIndex + 1}/${expectedCount}`;


      const clean =
        await loadCharacterSearch(
          worker,
          searchUrl
        );


      if (!clean) {

        continue;

      }


      cards =
        collectVerifiedSearchCards(
          worker.document
        );


      if (
        cardIndex >=
        cards.length
      ) {

        continue;

      }


      const cardInfo =
        cards[
          cardIndex
        ];


      if (
        !creatorMatchesExpected(
          cardInfo.card,
          "search"
        )
      ) {

        continue;

      }


      const fallbackTitle =
        getCardFallbackTitle(
          cardInfo,
          character.name
        );


      const sceneUrl =
        await clickSceneCard(
          worker,
          cardInfo
        );


      if (!sceneUrl) {

        continue;

      }


      const sceneId =
        getSceneId(
          sceneUrl
        );


      if (!sceneId) {

        continue;

      }


      const modal =
        await waitForSceneModal(
          worker
        );


      if (!modal) {

        continue;

      }


      await sleep(
        AFTER_CLICK_DELAY
      );


      /* ========================================================
         VISIBILITY CHECK
         ======================================================== */

      const visibility =
        getSceneVisibility(
          worker.document
        );


      console.log(
        "Visibility:",
        visibility
      );


      /*
      Unknown is ALWAYS rejected.
      */

      if (
        visibility ===
        "unknown"
      ) {

        console.warn(
          "Could not verify scene visibility — skipped."
        );


        continue;

      }


      /*
      Private/hidden scenes require explicit per-character permission.
      */

      if (
        visibility ===
          "private" &&
        !character
          .allowHiddenScenes
      ) {

        console.log(
          "%cPRIVATE SCENE — SKIPPED",
          "color:#f6c453;font-weight:bold"
        );


        continue;

      }


      if (
        visibility ===
        "private" &&
        character
          .allowHiddenScenes
      ) {

        console.log(
          "%cPRIVATE SCENE — ALLOWED FOR THIS CHARACTER",
          "color:#e778ff;font-weight:bold"
        );

      }


      /* ========================================================
         CREATOR CHECK
         ======================================================== */

      if (
        !sceneCreatorVerified(
          worker.document
        )
      ) {

        console.warn(
          "Scene creator mismatch — skipped."
        );


        continue;

      }


      /* ========================================================
         EXACT CHARACTER CHECK WHEN AVAILABLE
         ======================================================== */

      const exactCharacter =
        verifyExactCharacterIfAvailable(
          worker.document,
          character
        );


      if (
        exactCharacter.available &&
        !exactCharacter.matches
      ) {

        console.warn(
          "Scene linked to a different character — skipped."
        );


        continue;

      }


      const title =
        getRealSceneTitle(
          worker.document,
          fallbackTitle
        );


      const titleImageUrl =
        getSceneTitleImageUrl(
          worker.document,
          cardInfo.searchImageUrl
        );


      /*
      Final dedupe = scene UUID.
      */

      if (
        !captured.has(
          sceneId
        )
      ) {

        captured.set(
          sceneId,
          {

            id:
              sceneId,

            title,

            visibility,

            url:
              sceneUrl,

            titleImageUrl,

            messageCountDisplay:
              cardInfo.messageCount?.display ||
              "",

            messageCount:
              Number.isFinite(
                cardInfo.messageCount?.value
              )
                ? cardInfo.messageCount.value
                : null

          }
        );


        console.log(
          "%cCAPTURED",
          visibility ===
            "private"
            ? "color:#e778ff;font-weight:bold"
            : "color:#67e493;font-weight:bold",
          {

            title,

            visibility,

            url:
              sceneUrl,

            titleImageUrl,

            messageCountDisplay:
              cardInfo.messageCount?.display ||
              "",

            messageCount:
              Number.isFinite(
                cardInfo.messageCount?.value
              )
                ? cardInfo.messageCount.value
                : null

          }
        );

      }

    }


    const scenes =
      [
        ...captured.values()
      ];


    console.log(
      "Final scenes:",
      scenes.length
    );


    console.table(
      scenes
    );


    console.groupEnd();


    return scenes;

  }


  /* ============================================================
     OUTPUT
     ============================================================ */

  function formatCompactCount(
    value
  ) {

    if (
      !Number.isFinite(
        value
      )
    ) {

      return "Unknown";

    }


    const absolute =
      Math.abs(
        value
      );


    const format =
      (
        divisor,
        suffix
      ) => {

        const scaled =
          value /
          divisor;


        const rounded =
          Math.round(
            scaled *
            100
          ) /
          100;


        return String(
          rounded
        ) +
        suffix;

      };


    if (
      absolute >=
      1_000_000_000
    ) {

      return format(
        1_000_000_000,
        "B"
      );

    }


    if (
      absolute >=
      1_000_000
    ) {

      return format(
        1_000_000,
        "M"
      );

    }


    if (
      absolute >=
      1_000
    ) {

      return format(
        1_000,
        "K"
      );

    }


    return String(
      Math.round(
        value
      )
    );

  }


  function getCharacterPopularity(
    data
  ) {

    return data
      .map(
        (
          character,
          originalIndex
        ) => {

          const knownScenes =
            character.scenes
              .filter(
                scene =>
                  Number.isFinite(
                    scene.messageCount
                  )
              );


          const totalMessageCount =
            knownScenes
              .reduce(
                (
                  total,
                  scene
                ) =>
                  total +
                  scene.messageCount,
                0
              );


          return {

            name:
              character.name,

            handle:
              character.handle,

            profileUrl:
              character.profileUrl,

            allowHiddenScenes:
              character.allowHiddenScenes,

            sceneCount:
              character.scenes.length,

            countedSceneCount:
              knownScenes.length,

            unknownSceneCount:
              character.scenes.length -
              knownScenes.length,

            totalMessageCount:
              knownScenes.length
                ? totalMessageCount
                : null,

            totalMessageCountDisplay:
              knownScenes.length
                ? formatCompactCount(
                    totalMessageCount
                  )
                : "Unknown",

            originalIndex

          };

        }
      )
      .sort(
        (a, b) => {

          const aKnown =
            Number.isFinite(
              a.totalMessageCount
            );


          const bKnown =
            Number.isFinite(
              b.totalMessageCount
            );


          if (
            aKnown !==
            bKnown
          ) {

            return aKnown
              ? -1
              : 1;

          }


          if (
            aKnown &&
            bKnown &&
            a.totalMessageCount !==
              b.totalMessageCount
          ) {

            return b.totalMessageCount -
              a.totalMessageCount;

          }


          return a.originalIndex -
            b.originalIndex;

        }
      );

  }


  function flattenScenes(
    data
  ) {

    const characterPopularity =
      getCharacterPopularity(
        data
      );


    const totalsByHandle =
      new Map(
        characterPopularity
          .map(
            item => [
              String(
                item.handle ||
                item.name
              ).toLocaleLowerCase(),
              item
            ]
          )
      );


    return data
      .flatMap(
        (
          character,
          characterIndex
        ) =>
          character.scenes.map(
            (
              scene,
              sceneIndex
            ) => ({

              characterName:
                character.name,

              characterHandle:
                character.handle,

              characterProfileUrl:
                character.profileUrl,

              allowHiddenScenes:
                character.allowHiddenScenes,

              characterIndex,

              characterSceneNumber:
                sceneIndex +
                1,

              characterPopularity:
                totalsByHandle.get(
                  String(
                    character.handle ||
                    character.name
                  ).toLocaleLowerCase()
                ) ||
                null,

              scene

            })
          )
      );

  }


  function getScenesInDisplayOrder(
    data,
    sortMode
  ) {

    const flattened =
      flattenScenes(
        data
      );


    if (
      sortMode ===
        "popular" ||
      sortMode ===
        "least"
    ) {

      flattened.sort(
        (a, b) => {

          const aKnown =
            Number.isFinite(
              a.scene.messageCount
            );


          const bKnown =
            Number.isFinite(
              b.scene.messageCount
            );


          if (
            aKnown !==
            bKnown
          ) {

            return aKnown
              ? -1
              : 1;

          }


          if (
            !aKnown &&
            !bKnown
          ) {

            return (
              a.characterIndex -
                b.characterIndex ||
              a.characterSceneNumber -
                b.characterSceneNumber
            );

          }


          const difference =
            sortMode ===
              "popular"
              ? b.scene.messageCount -
                a.scene.messageCount
              : a.scene.messageCount -
                b.scene.messageCount;


          return difference ||
            a.characterIndex -
              b.characterIndex ||
            a.characterSceneNumber -
              b.characterSceneNumber;

        }
      );


      return flattened;

    }


    if (
      sortMode ===
      "character-popular"
    ) {

      const characterRanks =
        new Map(
          getCharacterPopularity(
            data
          ).map(
            (
              item,
              index
            ) => [
              String(
                item.handle ||
                item.name
              ).toLocaleLowerCase(),
              index
            ]
          )
        );


      flattened.sort(
        (a, b) => {

          const aRank =
            characterRanks.get(
              String(
                a.characterHandle ||
                a.characterName
              ).toLocaleLowerCase()
            ) ??
            Number.MAX_SAFE_INTEGER;


          const bRank =
            characterRanks.get(
              String(
                b.characterHandle ||
                b.characterName
              ).toLocaleLowerCase()
            ) ??
            Number.MAX_SAFE_INTEGER;


          return aRank -
            bRank ||
            a.characterSceneNumber -
              b.characterSceneNumber;

        }
      );

    }


    return flattened;

  }


  function getCharactersInDisplayOrder(
    data,
    sortMode
  ) {

    if (
      sortMode !==
      "character-popular"
    ) {

      return data;

    }


    const rank =
      new Map(
        getCharacterPopularity(
          data
        ).map(
          (
            item,
            index
          ) => [
            String(
              item.handle ||
              item.name
            ).toLocaleLowerCase(),
            index
          ]
        )
      );


    return data
      .slice()
      .sort(
        (a, b) => {

          const aRank =
            rank.get(
              String(
                a.handle ||
                a.name
              ).toLocaleLowerCase()
            ) ??
            Number.MAX_SAFE_INTEGER;


          const bRank =
            rank.get(
              String(
                b.handle ||
                b.name
              ).toLocaleLowerCase()
            ) ??
            Number.MAX_SAFE_INTEGER;


          return aRank -
            bRank;

        }
      );

  }


  function toPlainText(
    data,
    sortMode =
      "character"
  ) {

    const lines =
      [];


    const popularity =
      getCharacterPopularity(
        data
      );


    if (
      sortMode ===
        "popular" ||
      sortMode ===
        "least"
    ) {

      const scenes =
        getScenesInDisplayOrder(
          data,
          sortMode
        );


      lines.push(
        sortMode === "popular"
          ? "MOST POPULAR SCENES — OVERALL"
          : "LEAST POPULAR SCENES — OVERALL"
      );

      lines.push(
        ""
      );

      scenes.forEach(
        (
          item,
          index
        ) => {

          const scene =
            item.scene;


          lines.push(
            `#${index + 1} ${item.characterName} — ${scene.title}`
          );

          lines.push(
            `- Visibility: ${scene.visibility.toUpperCase()}`
          );

          lines.push(
            `- Messages: ${scene.messageCountDisplay || (Number.isFinite(scene.messageCount) ? scene.messageCount : "Unknown")}`
          );

          lines.push(
            `- Scene URL: ${scene.url}`
          );

          lines.push(
            `- Scene title image URL: ${scene.titleImageUrl || ""}`
          );

          lines.push(
            ""
          );

        }
      );


      lines.push(
        "",
        "MOST POPULAR CHARACTERS — TOTAL SCENE MESSAGES",
        ""
      );


      popularity.forEach(
        (
          character,
          index
        ) => {

          lines.push(
            `${index + 1}. ${character.name} — ${character.totalMessageCountDisplay} total messages (${character.countedSceneCount}/${character.sceneCount} scenes counted)`
          );

        }
      );


      return lines.join(
        "\n"
      );

    }


    lines.push(
      "MOST POPULAR CHARACTERS — TOTAL SCENE MESSAGES"
    );


    lines.push(
      ""
    );


    popularity
      .forEach(
        (
          character,
          index
        ) => {

          lines.push(
            `${index + 1}. ${character.name} — ${character.totalMessageCountDisplay} total messages (${character.countedSceneCount}/${character.sceneCount} scenes counted)`
          );

        }
      );


    lines.push(
      "",
      "SCENES",
      ""
    );


    for (
      const character of getCharactersInDisplayOrder(
        data,
        sortMode
      )
    ) {

      const characterTotal =
        popularity.find(
          item =>
            String(
              item.handle ||
              item.name
            ).toLocaleLowerCase() ===
            String(
              character.handle ||
              character.name
            ).toLocaleLowerCase()
        );


      lines.push(
        character.name
      );


      if (
        characterTotal
      ) {

        lines.push(
          `- Total messages across scenes: ${characterTotal.totalMessageCountDisplay}`
        );

        lines.push(
          `- Counted scenes: ${characterTotal.countedSceneCount}/${characterTotal.sceneCount}`
        );

      }


      lines.push(
        ""
      );


      character.scenes
        .forEach(
          (
            scene,
            index
          ) => {

            const number =
              index +
              1;


            lines.push(
              `- Scene ${number} title: ${scene.title}`
            );


            lines.push(
              `- Scene ${number} visibility: ${scene.visibility.toUpperCase()}`
            );


            lines.push(
              `- Scene ${number} messages: ${scene.messageCountDisplay || (Number.isFinite(scene.messageCount) ? scene.messageCount : "Unknown")}`
            );


            lines.push(
              `- Scene ${number} URL: ${scene.url}`
            );


            lines.push(
              `- Scene ${number} title image URL: ${scene.titleImageUrl || ""}`
            );


            lines.push(
              ""
            );

          }
        );


      lines.push(
        ""
      );

    }


    return lines.join(
      "\n"
    );

  }



  function toCsv(
    data,
    sortMode =
      "character"
  ) {

    const rows =
      [
        [
          "display_rank",
          "character_name",
          "character_handle",
          "character_url",
          "character_total_message_count_display",
          "character_total_message_count",
          "character_counted_scene_count",
          "character_scene_count",
          "allow_hidden_scenes",
          "character_scene_number",
          "scene_id",
          "scene_title",
          "scene_visibility",
          "scene_message_count_display",
          "scene_message_count",
          "scene_url",
          "scene_title_image_url"
        ]
      ];


    const orderedScenes =
      getScenesInDisplayOrder(
        data,
        sortMode
      );


    orderedScenes
      .forEach(
        (
          item,
          displayIndex
        ) => {

          const total =
            item.characterPopularity;


          rows.push(
            [
              displayIndex +
                1,
              item.characterName,
              item.characterHandle,
              item.characterProfileUrl,
              total?.totalMessageCountDisplay ||
                "Unknown",
              Number.isFinite(
                total?.totalMessageCount
              )
                ? total.totalMessageCount
                : "",
              total?.countedSceneCount ??
                "",
              total?.sceneCount ??
                "",
              item.allowHiddenScenes,
              item.characterSceneNumber,
              item.scene.id,
              item.scene.title,
              item.scene.visibility,
              item.scene.messageCountDisplay ||
                "",
              Number.isFinite(
                item.scene.messageCount
              )
                ? item.scene.messageCount
                : "",
              item.scene.url,
              item.scene.titleImageUrl
            ]
          );

        }
      );


    return rows
      .map(
        row =>
          row
            .map(
              value =>
                `"${String(
                  value ??
                  ""
                ).replaceAll(
                  '"',
                  '""'
                )}"`
            )
            .join(",")
      )
      .join("\n");

  }


  function getJsonExportData(
    data,
    sortMode
  ) {

    const popularity =
      getCharacterPopularity(
        data
      ).map(
        (
          item,
          index
        ) => ({

          rank:
            index +
            1,

          name:
            item.name,

          handle:
            item.handle,

          profileUrl:
            item.profileUrl,

          totalMessageCountDisplay:
            item.totalMessageCountDisplay,

          totalMessageCount:
            item.totalMessageCount,

          countedSceneCount:
            item.countedSceneCount,

          sceneCount:
            item.sceneCount,

          unknownSceneCount:
            item.unknownSceneCount

        })
      );


    const scenesInDisplayedOrder =
      getScenesInDisplayOrder(
        data,
        sortMode
      ).map(
        (
          item,
          index
        ) => ({

          rank:
            index +
            1,

          characterName:
            item.characterName,

          characterHandle:
            item.characterHandle,

          characterProfileUrl:
            item.characterProfileUrl,

          characterTotalMessageCountDisplay:
            item.characterPopularity?.totalMessageCountDisplay ||
            "Unknown",

          characterTotalMessageCount:
            Number.isFinite(
              item.characterPopularity?.totalMessageCount
            )
              ? item.characterPopularity.totalMessageCount
              : null,

          characterSceneNumber:
            item.characterSceneNumber,

          ...item.scene

        })
      );


    return {
      sortMode,
      characterPopularity:
        popularity,
      scenesInDisplayedOrder
    };

  }


  async function copyText(
    text
  ) {

    try {

      await navigator
        .clipboard
        .writeText(
          text
        );


      return true;

    } catch {}


    try {

      const textarea =
        document.createElement(
          "textarea"
        );


      textarea.value =
        text;


      textarea.style.position =
        "fixed";


      textarea.style.opacity =
        "0";


      document.body
        .appendChild(
          textarea
        );


      textarea.select();


      const success =
        document.execCommand(
          "copy"
        );


      textarea.remove();


      return success;

    } catch {

      return false;

    }

  }


  function download(
    filename,
    content,
    mime
  ) {

    const blob =
      new Blob(
        [
          content
        ],
        {
          type:
            mime
        }
      );


    const objectUrl =
      URL.createObjectURL(
        blob
      );


    const anchor =
      document.createElement(
        "a"
      );


    anchor.href =
      objectUrl;


    anchor.download =
      filename;


    document.body
      .appendChild(
        anchor
      );


    anchor.click();


    anchor.remove();


    setTimeout(
      () =>
        URL.revokeObjectURL(
          objectUrl
        ),
      1000
    );

  }


  /* ============================================================
     UI
     ============================================================ */

  const panel =
    document.createElement(
      "div"
    );


  panel.id =
    "clank-scene-collector-v7";


  panel.innerHTML = `

<style>

#clank-scene-collector-v7 {

  position: fixed;

  top: 16px;
  right: 16px;

  z-index: 2147483647;

  width:
    min(
      620px,
      calc(100vw - 32px)
    );

  max-height:
    calc(100vh - 32px);

  overflow: auto;

  padding: 16px;

  background: #0b111c;

  color: #f5f7ff;

  border:
    1px solid
    rgba(255,255,255,.17);

  border-radius: 16px;

  box-shadow:
    0 24px 80px
    rgba(0,0,0,.70);

  font:
    13px/1.45
    Inter,
    system-ui,
    sans-serif;

}


#clank-scene-collector-v7 * {

  box-sizing:
    border-box;

}


#clank-scene-collector-v7 h2 {

  margin:
    0 0 3px;

  font-size:
    19px;

}


#clank-scene-collector-v7 .sub {

  margin-bottom:
    10px;

  color:
    #8998b0;

  font-size:
    11px;

}


#clank-scene-collector-v7 .box {

  margin:
    10px 0;

  padding:
    11px;

  background:
    #151e2e;

  border-radius:
    10px;

  color:
    #cbd6e8;

  font-size:
    11px;

}


#clank-scene-collector-v7 .verified {

  background:
    #10251a;

  border:
    1px solid
    rgba(87,220,140,.25);

}


#clank-scene-collector-v7 input[type="text"] {

  width:
    100%;

  padding:
    8px 9px;

  background:
    #090f19;

  color:
    white;

  border:
    1px solid
    rgba(255,255,255,.17);

  border-radius:
    8px;

  outline:
    none;

}


#clank-scene-collector-v7 button {

  padding:
    8px 10px;

  border:
    1px solid
    rgba(255,255,255,.15);

  border-radius:
    8px;

  background:
    #19243a;

  color:
    white;

  cursor:
    pointer;

  font:
    inherit;

  font-weight:
    700;

}


#clank-scene-collector-v7 button:hover:not(:disabled) {

  background:
    #263853;

}


#clank-scene-collector-v7 button:disabled {

  opacity:
    .42;

  cursor:
    not-allowed;

}


#clank-scene-collector-v7 button.primary {

  background:
    #245fa8;

}


#clank-scene-collector-v7 button.danger {

  background:
    #3a1d27;

}


#clank-scene-collector-v7 .actions,
#clank-scene-collector-v7 .picker-tools {

  display:
    flex;

  flex-wrap:
    wrap;

  gap:
    7px;

  margin:
    10px 0;

}


#clank-scene-collector-v7 .progress {

  height:
    7px;

  margin:
    9px 0;

  overflow:
    hidden;

  border-radius:
    999px;

  background:
    #19212f;

}


#clank-scene-collector-v7 .bar {

  width:
    0%;

  height:
    100%;

  background:
    #78a8ff;

  transition:
    width .15s linear;

}


#clank-scene-collector-v7 .status {

  min-height:
    35px;

  color:
    #b9c5d9;

  font-size:
    11px;

}


#clank-scene-collector-v7 .picker {

  margin-top:
    12px;

  padding:
    12px;

  background:
    #101824;

  border:
    1px solid
    rgba(255,255,255,.10);

  border-radius:
    12px;

}


#clank-scene-collector-v7 .picker-header {

  margin-bottom:
    10px;

}


#clank-scene-collector-v7 .picker-header > b {

  font-size:
    15px;

}


#clank-scene-collector-v7 .picker-sub {

  margin-top:
    2px;

  color:
    #8998ae;

  font-size:
    10px;

}


#clank-scene-collector-v7 .selection-summary {

  margin:
    9px 0;

  padding:
    8px 9px;

  background:
    #0a111c;

  border-radius:
    8px;

  color:
    #aebcd1;

  font-size:
    10px;

}


#clank-scene-collector-v7 .character-list {

  max-height:
    410px;

  overflow-y:
    auto;

  padding-right:
    4px;

  border-top:
    1px solid
    rgba(255,255,255,.08);

  border-bottom:
    1px solid
    rgba(255,255,255,.08);

}


#clank-scene-collector-v7 .character-row {

  display:
    grid;

  grid-template-columns:
    minmax(0,1fr)
    auto;

  gap:
    12px;

  align-items:
    center;

  padding:
    10px 6px;

  border-bottom:
    1px solid
    rgba(255,255,255,.06);

}


#clank-scene-collector-v7 .character-row:last-child {

  border-bottom:
    none;

}


#clank-scene-collector-v7 .character-row.not-selected {

  opacity:
    .46;

}


#clank-scene-collector-v7 .character-row.hidden-enabled {

  background:
    rgba(196,83,255,.08);

}


#clank-scene-collector-v7 .scan-label,
#clank-scene-collector-v7 .hidden-label {

  display:
    flex;

  gap:
    7px;

  align-items:
    center;

  cursor:
    pointer;

}


#clank-scene-collector-v7 .scan-label {

  min-width:
    0;

}


#clank-scene-collector-v7 .scan-label span {

  min-width:
    0;

}


#clank-scene-collector-v7 .scan-label b {

  display:
    block;

  overflow:
    hidden;

  white-space:
    nowrap;

  text-overflow:
    ellipsis;

}


#clank-scene-collector-v7 .scan-label small {

  display:
    block;

  margin-top:
    1px;

  color:
    #8292aa;

  font-size:
    9px;

}


#clank-scene-collector-v7 .hidden-label {

  color:
    #d8a3ef;

  white-space:
    nowrap;

  font-size:
    10px;

}


#clank-scene-collector-v7 input[type="checkbox"] {

  accent-color:
    #72a8ff;

}


#clank-scene-collector-v7 .picker-footer {

  margin-top:
    11px;

  text-align:
    right;

}


#clank-scene-collector-v7 .picker-locked {

  opacity:
    .65;

}


#clank-scene-collector-v7 details {

  padding:
    8px 0;

  border-top:
    1px solid
    rgba(255,255,255,.09);

}


#clank-scene-collector-v7 summary {

  cursor:
    pointer;

  font-weight:
    750;

}


#clank-scene-collector-v7 .scene {

  margin:
    9px 0 13px 10px;

  padding:
    10px;

  background:
    rgba(255,255,255,.035);

  border-radius:
    8px;

}


#clank-scene-collector-v7 .visibility {

  display:
    inline-block;

  margin:
    5px 0;

  padding:
    2px 6px;

  border-radius:
    999px;

  font-size:
    9px;

  font-weight:
    800;

}


#clank-scene-collector-v7 .visibility.public {

  background:
    rgba(52,200,120,.15);

  color:
    #72e8a3;

}


#clank-scene-collector-v7 .visibility.private {

  background:
    rgba(205,91,255,.15);

  color:
    #e392ff;

}


#clank-scene-collector-v7 .label {

  margin-top:
    5px;

  color:
    #8493aa;

  font-size:
    9px;

}


#clank-scene-collector-v7 .url {

  display:
    block;

  color:
    #91b9ff;

  font-size:
    9px;

  overflow-wrap:
    anywhere;

  text-decoration:
    none;

}


#clank-scene-collector-v7 .thumb {

  display:
    block;

  width:
    135px;

  max-height:
    110px;

  margin-top:
    7px;

  object-fit:
    cover;

  border-radius:
    7px;

}


#clank-scene-collector-v7 .sort-wrap {

  display:
    flex;

  align-items:
    center;

  gap:
    6px;

  color:
    #9dafc9;

  font-size:
    10px;

}


#clank-scene-collector-v7 .sort-mode {

  padding:
    7px 9px;

  border:
    1px solid
    rgba(255,255,255,.15);

  border-radius:
    8px;

  background:
    #101827;

  color:
    #f5f7ff;

  font:
    inherit;

  outline:
    none;

}


#clank-scene-collector-v7 .popularity {

  display:
    inline-block;

  margin:
    5px 5px 5px 0;

  padding:
    2px 6px;

  border:
    1px solid
    rgba(121,174,255,.24);

  border-radius:
    999px;

  background:
    rgba(61,105,175,.16);

  color:
    #a9c8ff;

  font-size:
    9px;

  font-weight:
    800;

}


#clank-scene-collector-v7 .leaderboard-rank {

  color:
    #7eaaff;

  font-size:
    10px;

  font-weight:
    900;

}


#clank-scene-collector-v7 .character-popularity-summary {

  margin:
    9px 0;

}


#clank-scene-collector-v7 .character-popularity-row {

  display:
    grid;

  grid-template-columns:
    34px minmax(0,1fr) auto;

  align-items:
    center;

  gap:
    8px;

  padding:
    6px 0;

  border-bottom:
    1px solid rgba(255,255,255,.06);

}


#clank-scene-collector-v7 .character-popularity-row:last-child {

  border-bottom:
    0;

}


#clank-scene-collector-v7 .character-popularity-name {

  min-width:
    0;

  overflow:
    hidden;

  text-overflow:
    ellipsis;

  white-space:
    nowrap;

  color:
    #f2f5fb;

  font-weight:
    800;

}


#clank-scene-collector-v7 .character-popularity-total {

  color:
    #a9c8ff;

  font-size:
    10px;

  font-weight:
    900;

  white-space:
    nowrap;

}


#clank-scene-collector-v7 .close {

  position:
    absolute;

  top:
    8px;
  right:
    9px;

  padding:
    4px 7px;

  background:
    transparent;

}

</style>


<button
  class="close"
  title="Close"
>
  ×
</button>


<h2>
  Clank Scene Collector
</h2>


<div class="sub">
  Select characters + per-character hidden/private scene control
</div>


<div class="box verified">

  <b>
    User profile
  </b>

  <br>

  ${escapeHtml(USER_PROFILE_URL)}

  <br><br>

  Screen name:

  <input
    type="text"
    class="screen-name"
    value="${escapeHtml(AUTO_SCREEN_NAME)}"
    placeholder="Example: Sam"
  >

</div>


<div class="box">

  <b>
    Workflow
  </b>

  <br><br>

  1. Discover characters from
  <b>/your-characters</b>.

  <br>

  2. Choose which characters you want scanned.

  <br>

  3. Optionally enable
  <b>hidden/private scenes</b>
  for individual characters.

  <br>

  4. Extract verified scenes.

</div>


<div class="actions">

  <button
    class="discover primary"
  >
    Discover Characters
  </button>

  <button
    class="cancel danger"
    disabled
  >
    Cancel
  </button>

</div>


<div class="progress">
  <div class="bar"></div>
</div>


<div class="status">
  Ready.
</div>


<div
  class="picker"
  hidden
></div>


<div
  class="actions exports"
  hidden
>

  <label class="sort-wrap">
    Sort
    <select class="sort-mode">
      <option value="character">Character / scan order</option>
      <option value="popular">Most popular scenes overall</option>
      <option value="least">Least popular scenes overall</option>
      <option value="character-popular">Most popular characters first</option>
    </select>
  </label>

  <button class="copy">
    Copy Results
  </button>

  <button class="json">
    Download JSON
  </button>

  <button class="csv">
    Download CSV
  </button>

</div>


<div class="results"></div>

`;


  document.body
    .appendChild(
      panel
    );


  const $ =
    selector =>
      panel.querySelector(
        selector
      );


  const discoverButton =
    $(".discover");


  const cancelButton =
    $(".cancel");


  const screenNameInput =
    $(".screen-name");


  const progressBar =
    $(".bar");


  const status =
    $(".status");


  const pickerElement =
    $(".picker");


  const exportsElement =
    $(".exports");


  const sortModeElement =
    $(".sort-mode");


  const resultsElement =
    $(".results");


  /* ============================================================
     RESULTS UI
     ============================================================ */

  function renderResults() {

    if (
      results.length ===
      0
    ) {

      resultsElement.innerHTML = `

<div class="box">
  No verified scenes were collected.
</div>

`;


      return;

    }


    const sortMode =
      sortModeElement?.value ||
      "character";


    const characterPopularity =
      getCharacterPopularity(
        results
      );


    const characterSummaryHtml = (
      sortMode === "popular" ||
      sortMode === "least"
    )
      ? ""
      : `

<div class="box verified character-popularity-summary">

  <b>
    Most popular characters — combined scene messages
  </b>

  <div class="label">
    Totals add the numeric message count captured from every scene with a known count.
  </div>

  ${characterPopularity.map(
    (
      character,
      index
    ) => `

<div class="character-popularity-row">
  <span class="leaderboard-rank">#${index + 1}</span>
  <span class="character-popularity-name">${escapeHtml(character.name)}</span>
  <span class="character-popularity-total">${escapeHtml(character.totalMessageCountDisplay)} total</span>
</div>

`
  ).join("")}

</div>

`;


    const sceneCardHtml =
      (
        scene,
        options = {}
      ) => {

        const rank =
          Number.isFinite(
            options.rank
          )
            ? `<span class="leaderboard-rank">#${options.rank}</span><br>`
            : "";


        const characterLine =
          options.characterName
            ? `<div class="label">Character</div><b>${escapeHtml(options.characterName)}</b>`
            : "";


        const popularity =
          scene.messageCountDisplay ||
          (
            Number.isFinite(
              scene.messageCount
            )
              ? String(
                  scene.messageCount
                )
              : "Unknown"
          );


        return `

<div class="scene">

  ${rank}

  <b>
    ${options.titlePrefix || "Scene"}:
    ${escapeHtml(scene.title)}
  </b>

  <br>

  <span
    class="visibility ${escapeHtml(scene.visibility)}"
  >
    ${escapeHtml(scene.visibility.toUpperCase())}
  </span>

  <span class="popularity">
    ${escapeHtml(popularity)} messages
  </span>

  ${characterLine}

  <div class="label">
    Scene URL
  </div>

  <a
    class="url"
    href="${escapeHtml(scene.url)}"
    target="_blank"
    rel="noopener noreferrer"
  >
    ${escapeHtml(scene.url)}
  </a>


  <div class="label">
    Scene title image URL
  </div>

  ${
    scene.titleImageUrl
      ? `

<a
  class="url"
  href="${escapeHtml(scene.titleImageUrl)}"
  target="_blank"
  rel="noopener noreferrer"
>
  ${escapeHtml(scene.titleImageUrl)}
</a>

<img
  class="thumb"
  src="${escapeHtml(scene.titleImageUrl)}"
  alt=""
>

`
      : `

<span class="url">
  No image URL detected
</span>

`
  }

</div>

`;

      };


    if (
      sortMode ===
        "popular" ||
      sortMode ===
        "least"
    ) {

      const flattened =
        getScenesInDisplayOrder(
          results,
          sortMode
        );


      const knownCount =
        flattened.filter(
          item =>
            Number.isFinite(
              item.scene.messageCount
            )
        ).length;


      resultsElement.innerHTML = `

<div class="box verified">
  <b>${flattened.length}</b> scenes total •
  <b>${knownCount}</b> with message counts •
  ${sortMode === "popular" ? "highest first" : "lowest first"} •
  overall across all collected characters
</div>

${flattened.map(
  (
    item,
    index
  ) =>
    sceneCardHtml(
      item.scene,
      {
        rank:
          index + 1,
        characterName:
          item.characterName,
        titlePrefix:
          "Scene"
      }
    )
).join("")}

`;


      return;

    }


    const orderedCharacters =
      getCharactersInDisplayOrder(
        results,
        sortMode
      );


    resultsElement.innerHTML = `

${characterSummaryHtml}

<div class="box verified">

  <b>
    ${results.length}
  </b>

  characters produced at least one verified scene.

  ${sortMode === "character-popular" ? "• characters ordered by combined scene messages" : ""}

</div>


${orderedCharacters.map(
  character => {

    const total =
      characterPopularity.find(
        item =>
          String(
            item.handle ||
            item.name
          ).toLocaleLowerCase() ===
          String(
            character.handle ||
            character.name
          ).toLocaleLowerCase()
      );


    return `

<details>

  <summary>

    ${escapeHtml(character.name)}

    —

    ${character.scenes.length}
    scene${character.scenes.length === 1 ? "" : "s"}

    • ${escapeHtml(total?.totalMessageCountDisplay || "Unknown")} total messages

    ${character.allowHiddenScenes
      ? " • hidden allowed"
      : ""
    }

  </summary>


  ${character.scenes.map(
    (
      scene,
      index
    ) =>
      sceneCardHtml(
        scene,
        {
          titlePrefix:
            `Scene ${index + 1} title`
        }
      )
  ).join("")}

</details>

`;

  }
).join("")}

`;

  }



  /* ============================================================
     OPEN WORKER
     ============================================================ */

  function ensureWorker() {

    if (
      worker &&
      !worker.closed
    ) {

      return worker;

    }


    worker =
      window.open(

        "about:blank",

        "clank_scene_collector_worker",

        "width=1200,height=900,resizable=yes,scrollbars=yes"

      );


    return worker;

  }


  /* ============================================================
     STAGE 1 — DISCOVERY
     ============================================================ */

  async function beginDiscovery() {

    if (
      phase ===
        "discovering" ||
      phase ===
        "scanning"
    ) {

      return;

    }


    EXPECTED_SCREEN_NAME =
      cleanText(
        screenNameInput.value
      );


    if (
      !EXPECTED_SCREEN_NAME
    ) {

      status.textContent =
        "Enter or verify your Clank screen name first.";


      screenNameInput.focus();


      return;

    }


    cancelled =
      false;


    phase =
      "discovering";


    results =
      [];


    errors =
      [];


    DISCOVERED_CHARACTERS =
      [];


    CHARACTERS =
      [];


    resultsElement.innerHTML =
      "";


    pickerElement.hidden =
      true;


    pickerElement.innerHTML =
      "";


    exportsElement.hidden =
      true;


    progressBar.style.width =
      "0%";


    discoverButton.disabled =
      true;


    cancelButton.disabled =
      false;


    screenNameInput.disabled =
      true;


    const currentWorker =
      ensureWorker();


    if (
      !currentWorker
    ) {

      status.textContent =
        "Popup blocked. Allow popups for clank.world and try again.";


      phase =
        "idle";


      discoverButton.disabled =
        false;


      cancelButton.disabled =
        true;


      screenNameInput.disabled =
        false;


      return;

    }


    console.clear();


    console.log(
      "%cCLANK SCENE COLLECTOR",
      "font-size:17px;font-weight:bold;color:#78b7ff"
    );


    console.log(
      "User profile:",
      USER_PROFILE_URL
    );


    console.log(
      "Creator screen name:",
      EXPECTED_SCREEN_NAME
    );


    try {

      DISCOVERED_CHARACTERS =
        await discoverYourCharacters(
          currentWorker
        );


      phase =
        "selecting";


      progressBar.style.width =
        "50%";


      status.textContent =
        `Stage 1/2 complete — ${DISCOVERED_CHARACTERS.length} characters found. Choose which characters to scan.`;


      renderCharacterPicker();


      cancelButton.disabled =
        false;

    } catch (
      error
    ) {

      console.error(
        error
      );


      phase =
        "idle";


      status.textContent =
        String(
          error?.message ||
          error
        );


      discoverButton.disabled =
        false;


      cancelButton.disabled =
        true;


      screenNameInput.disabled =
        false;


      if (
        worker &&
        !worker.closed
      ) {

        try {

          worker.close();

        } catch {}

      }


      worker =
        null;

    }

  }


  /* ============================================================
     STAGE 2 — SELECTED SCAN
     ============================================================ */

  async function beginSelectedScan() {

    if (
      phase !==
      "selecting"
    ) {

      return;

    }


    CHARACTERS =
      getSelectedCharactersFromPicker();


    if (
      CHARACTERS.length ===
      0
    ) {

      status.textContent =
        "Select at least one character to scan.";


      return;

    }


    cancelled =
      false;


    phase =
      "scanning";


    results =
      [];


    errors =
      [];


    lockCharacterPicker();


    cancelButton.disabled =
      false;


    exportsElement.hidden =
      true;


    resultsElement.innerHTML =
      "";


    /*
    Worker may have been manually closed while the picker was open.
    Re-open if necessary.
    */

    const currentWorker =
      ensureWorker();


    if (
      !currentWorker
    ) {

      status.textContent =
        "Popup blocked. Allow popups and try again.";


      phase =
        "selecting";


      return;

    }


    console.log(
      `%cSTARTING SELECTED SCAN: ${CHARACTERS.length} characters`,
      "color:#dca0ff;font-weight:bold"
    );


    console.table(
      CHARACTERS.map(
        character => ({

          character:
            character.name,

          handle:
            character.handle,

          allowHidden:
            character.allowHiddenScenes

        })
      )
    );


    try {

      for (
        let index = 0;
        index <
        CHARACTERS.length;
        index++
      ) {

        if (
          cancelled
        ) {

          break;

        }


        const character =
          CHARACTERS[
            index
          ];


        progressBar.style.width =
          `${
            50 +
            Math.round(
              (
                index /
                CHARACTERS.length
              ) *
              50
            )
          }%`;


        status.textContent =
          `Stage 2/2 — ${index + 1}/${CHARACTERS.length}: ${character.name}`;


        try {

          const scenes =
            await collectCharacter(
              character,
              index
            );


          if (
            scenes.length >
            0
          ) {

            results.push(
              {

                name:
                  character.name,

                handle:
                  character.handle,

                profileUrl:
                  character.url,

                allowHiddenScenes:
                  character
                    .allowHiddenScenes,

                scenes

              }
            );

          }

        } catch (
          error
        ) {

          const message =
            String(
              error?.message ||
              error
            );


          if (
            message
              .toLocaleLowerCase()
              .includes(
                "cancelled"
              )
          ) {

            break;

          }


          console.error(
            character.name,
            error
          );


          errors.push(
            {

              character:
                character.name,

              error:
                message

            }
          );

        }

      }

    } finally {

      if (
        !cancelled
      ) {

        progressBar.style.width =
          "100%";

      }


      if (
        worker &&
        !worker.closed
      ) {

        try {

          worker.close();

        } catch {}

      }


      worker =
        null;


      phase =
        "done";


      cancelButton.disabled =
        true;


      discoverButton.disabled =
        false;


      screenNameInput.disabled =
        false;

    }


    if (
      cancelled
    ) {

      status.textContent =
        `Cancelled. ${results.length} characters produced collected scenes.`;

    } else {

      const sceneCount =
        results.reduce(
          (
            sum,
            character
          ) =>
            sum +
            character.scenes.length,
          0
        );


      const privateCount =
        results.reduce(
          (
            sum,
            character
          ) =>
            sum +
            character.scenes.filter(
              scene =>
                scene.visibility ===
                "private"
            ).length,
          0
        );


      status.textContent =
        `Finished — ${sceneCount} scenes from ${results.length} characters. ${privateCount} private/hidden scene${privateCount === 1 ? "" : "s"} included.`;


      exportsElement.hidden =
        false;

    }


    renderResults();


    console.log(
      "%cFINAL RESULTS",
      "font-size:16px;font-weight:bold;color:#67e493",
      results
    );


    if (
      errors.length
    ) {

      console.log(
        "Errors:",
        errors
      );

    }

  }


  /* ============================================================
     EVENTS
     ============================================================ */

  discoverButton.addEventListener(
    "click",
    beginDiscovery
  );


  cancelButton.addEventListener(
    "click",
    () => {

      cancelled =
        true;


      if (
        phase ===
        "selecting"
      ) {

        status.textContent =
          "Worker closed. Your character selections remain available.";

      } else {

        status.textContent =
          "Cancelling…";

      }


      if (
        worker &&
        !worker.closed
      ) {

        try {

          worker.close();

        } catch {}

      }


      worker =
        null;


      if (
        phase ===
        "selecting"
      ) {

        cancelButton.disabled =
          true;

      }

    }
  );


  $(".close")
    .addEventListener(
      "click",
      () => {

        cancelled =
          true;


        if (
          worker &&
          !worker.closed
        ) {

          try {

            worker.close();

          } catch {}

        }


        panel.remove();

      }
    );


  sortModeElement
    ?.addEventListener(
      "change",
      () => {

        renderResults();

      }
    );


  $(".copy")
    .addEventListener(
      "click",
      async () => {

        const success =
          await copyText(
            toPlainText(
              results,
              sortModeElement?.value ||
                "character"
            )
          );


        status.textContent =
          success
            ? "Results copied."
            : "Clipboard copy failed.";

      }
    );


  $(".json")
    .addEventListener(
      "click",
      () => {

        download(

          "clank_scene_index.json",

          JSON.stringify(
            {

              userProfile:
                USER_PROFILE_URL,

              creatorScreenName:
                EXPECTED_SCREEN_NAME,

              characterSource:
                YOUR_CHARACTERS_URL,

              selectedCharacters:
                CHARACTERS.map(
                  character => ({

                    name:
                      character.name,

                    handle:
                      character.handle,

                    profileUrl:
                      character.url,

                    allowHiddenScenes:
                      character
                        .allowHiddenScenes

                  })
                ),

              ...getJsonExportData(
                results,
                sortModeElement?.value ||
                  "character"
              ),

              characters:
                getCharactersInDisplayOrder(
                  results,
                  sortModeElement?.value ||
                    "character"
                )

            },
            null,
            2
          ),

          "application/json;charset=utf-8"

        );

      }
    );


  $(".csv")
    .addEventListener(
      "click",
      () => {

        download(

          "clank_scene_index.csv",

          toCsv(
            results,
            sortModeElement?.value ||
              "character"
          ),

          "text/csv;charset=utf-8"

        );

      }
    );

})();