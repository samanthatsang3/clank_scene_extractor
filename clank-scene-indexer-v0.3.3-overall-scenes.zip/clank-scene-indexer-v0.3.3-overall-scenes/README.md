# Clank Scene Indexer v0.3.3 — Overall scene popularity

## Changes

- **Most popular scenes first** is now explicitly a single overall cross-character leaderboard.
- When that scene sort is selected, the UI does **not** show the grouped-per-character results list.
- **Copy Results** for popular/least scene sorting now outputs the global scene leaderboard first, not the character sections.
- Character popularity totals are still available separately through **Most popular characters first** and in JSON export.

# Clank Scene Indexer — Popularity v0.3.2

This build keeps the proven console-parity collector and expands the popularity layer.

## Fixed

- **Copy Results now follows the selected Sort mode.**
- **CSV export now follows the selected Sort mode.**
- **JSON export now includes `scenesInDisplayedOrder` in the exact selected order.**
- JSON also records `sortMode`.

## Character popularity totals

The collector now adds the message counts of every known scene for each character and creates a descending character leaderboard.

Example:

- Scene A = 62.6K -> 62,600
- Scene B = 172K -> 172,000
- Character combined total = 234,600 -> displayed as 234.6K

Because Clank itself displays compact rounded counts, combined totals are derived/approximate totals of those displayed values. Scenes whose count cannot be detected remain in the results but do not contribute to the numeric total.

## New sort option

- Character / scan order
- Most popular scenes first
- Least popular scenes first
- **Most popular characters first**

## Exports

### Copy Results
Starts with `MOST POPULAR CHARACTERS — TOTAL SCENE MESSAGES`, then lists scenes in the currently selected order.

### JSON
Adds:

- `sortMode`
- `characterPopularity`
- `scenesInDisplayedOrder`
- `characters` (grouped data, reordered when Most popular characters is selected)

### CSV
Rows follow the current Sort setting and add:

- display rank
- character total message count
- character total display value
- counted-scene count
- total scene count

## Install/update

1. Unzip this folder.
2. Open `chrome://extensions`.
3. Disable/remove the previous unpacked version, or replace its files.
4. Load this folder with **Load unpacked**.
5. Refresh the Clank creator-profile page.
6. Launch the collector normally.
